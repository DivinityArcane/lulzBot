using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using lulzbot;
using lulzbot.Extensions;

[ExtensionInfo("Aways", "DivinityArcane", "1.0")]
public class Extension
{
    Dictionary<String, Away> data = null;

    private void Load()
    {
        data = Storage.Load<Dictionary<String, Away>>("aways");

        if (data == null)
            data = new Dictionary<String, Away>();
    }

    private void Save()
    {
        Storage.Save("aways", data);
    }
    
    [BindEvent("recv_msg")]
    [BindEvent("recv_action")]
    public void check_aways(dAmnPacket packet)
    {
        if (data == null)
            Load();

        String msg = packet.Body.ToLower();
        
        foreach (KeyValuePair<String, Away> kvp in data)
        {
            if (msg.StartsWith(kvp.Key.ToLower() + ": "))
            {
                Away away = kvp.Value;

                if (kvp.Key.ToLower() == packet.Arguments["from"].ToLower())
                {
                    // Ourself
                    return;
                }
                
                if (msg.Contains("-away"))
                {
                    // Override.
                    return;
                }

                if (away.LastMsg != 0 && Tools.Timestamp() - away.LastMsg < 60) // 1 minute
                {
                    // Too soon.
                    return;
                }
                
                away.LastMsg = Tools.Timestamp();
                
                LulzBot.Say(packet.Parameter, String.Format("{0}: {1} has been away for {2} ({3})", packet.Arguments["from"], away.RealName, Tools.FormatTime(Tools.Timestamp() - away.Timestamp), away.Reason));

				away.Highlights.Add(new Highlight()
					{
						Timestamp = Tools.Timestamp(),
						Channel = Tools.FormatChat(packet.Parameter),
						Name = packet.Arguments["from"],
						Message = packet.Body
					});
					
				data[kvp.Key] = away;
				Save();
				
                // Obviously can't start with two different names.
                return;
            }
        }
    }
    
    [BindCommand("away", "Command for allowing users to set themselves as away.", Privs.Guest, "[trig]away <i>reason</i>")]
    public void cmd_away(String chan, String msg, String[] args, String from)
    {
        if (data == null)
            Load();

        String helpmsg = String.Format("<b>&raquo; Usage:</b><br/>{0}away [reason]<br/>{0}back", " &middot; " + LulzBot.Trigger);
        String reason;
        
        if (args.Length == 1)
            reason = "no reason";
        else
            reason = msg.Substring(5);

        String who = from.ToLower();

        if (reason == "?" || reason == "-?" || reason == "help")
        {
            LulzBot.Say(chan, helpmsg);
            return;
        }
        
        Away away = new Away() {
            Timestamp = Tools.Timestamp(),
            LastMsg = 0,
            Reason = reason,
            RealName = from,
			Highlights = new List<Highlight>()
        };

        if (data.ContainsKey(who))
            // Allow overriding
            data[who] = away;
        else
            data.Add(who, away);

        Save();

        // Announce to all channels the bot and user have in common.
        foreach (String channel in Tools.MutualChannels(who))
        {
            LulzBot.Act(channel, String.Format(":megaphone: <i>{0} is now away.</i> ({1})", from, reason));
        }
    }

    [BindCommand("back", "Command for allowing users to set themselves as back.", Privs.Guest, "[trig]back")]
    public void cmd_back(String chan, String msg, String[] args, String from)
    {
        if (data == null)
        {
            Load();
            return;
        }

        String who = from.ToLower();

        if (data.ContainsKey(who))
        {
            Away away = data[who];
            
            // Announce to all channels the bot and user have in common.
            foreach (String channel in Tools.MutualChannels(who))
            {
                LulzBot.Act(channel, String.Format(":megaphone: <i>{0} is now back from <b>{2}</b>.</i> (After {1})", from, Tools.FormatTime(Tools.Timestamp() - away.Timestamp), away.Reason));
            }
			
			if (away.Highlights.Count > 0)
			{
				String op = String.Format("<b>&raquo; You were tabbed {0} time{1}:</b><br/>", away.Highlights.Count, away.Highlights.Count == 1 ? "" : "s");
				
				foreach (Highlight hl in away.Highlights)
				{
					op += String.Format("<br/><b> &middot; {0} ago in {1}:</b><br/> <b>&lt;{2}&gt;</b> {3}<br/>", Tools.FormatTime(Tools.Timestamp() - hl.Timestamp), hl.Channel, hl.Name, hl.Message);
				}
				
				LulzBot.Say(chan, op);
			}

            data.Remove(who);
            Save();
        }
        else
        {
            LulzBot.Say(chan, String.Format("{0}: You're not away.", from));
        }
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 0)]
public struct Highlight
{
    public int Timestamp;
    public String Name, Message, Channel;
} 

[StructLayout(LayoutKind.Sequential, Pack = 0)]
public struct Away
{
    public int Timestamp, LastMsg;
    public String Reason, RealName;
	public List<Highlight> Highlights;
} 
