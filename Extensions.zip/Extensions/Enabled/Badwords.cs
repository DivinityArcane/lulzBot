using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using lulzbot;
using lulzbot.Extensions;

[ExtensionInfo("Badwords", "DivinityArcane", "1.0")]
public class Extension
{    
    public struct ChatData
    {
        public bool Enabled;
        public List<String> BadWords;
    }
    
    private Dictionary<String, ChatData> data;
    
    private void Load()
    {
        data = Storage.Load<Dictionary<String, ChatData>>("badwords");
        
        if (data == null)
            data = new Dictionary<String, ChatData>();
    }
    
    private void Save()
    {
        Storage.Save("badwords", data);
    }
    
    private string[] Words(string msg)
    {
        List<char> chars = new List<char>();
        
        foreach (char c in msg.ToLower().ToCharArray())
        {
            if (((int)c >= 97 && (int)c <= 122) || (int)c == 32)
                chars.Add(c); 
        }
        
        return (new string(chars.ToArray())).Split(' ');
    }
    
    [BindEvent("recv_msg")]
    [BindEvent("recv_action")]
    public void e_badwords(dAmnPacket packet)
    {
        if (data == null) Load();
        
        String pns = packet.Parameter.ToLower();
        
        if (!data.ContainsKey(pns)) return;
        
        if (packet.Body.Length > 0)
        {
            foreach (string word in Words(packet.Body))
            {
                if (data[pns].BadWords.Contains(word))
                {
                    LulzBot.Kick(packet.Parameter, packet.Arguments["from"], "That word is not allowed to be used here!");
                    return;
                }
            }
        }
    }
    
    [BindCommand("badwords", "Bad words settings.", Privs.Operators)]
    public void cmd_badwords(String chan, String msg, String[] args, String from)
    {
        String helpmsg = String.Format("<b>&raquo; Usage:</b><br/>{0}badwords #channel on/off{0}badwords #channel add/del word{0}badwords #channel list", "<br/> &middot; " + LulzBot.Trigger);
        
        if (args.Length >= 3)
        {
            if (data == null) Load();
            
            if (!args[1].StartsWith("#") || args[1].Length < 2)
            {
                LulzBot.Say(chan, helpmsg);
                return;
            }
            
            String ns = args[1], arg = args[2], pns = Tools.FormatChat(ns).ToLower();
            
            if (arg == "on" || arg == "off")
            {
                if (!data.ContainsKey(pns))
                    data.Add(pns, new ChatData() { Enabled = false, BadWords = new List<String>() });
                    
                var cd = data[pns];
                cd.Enabled = (arg == "on");
                data[pns] = cd;
                
                Save();
                
                LulzBot.Say(chan, String.Format("<b>&raquo; BadWords for {0} has been turned {1}.</b>", ns, arg));
            }
            else if (arg == "list")
            {
                if (data.ContainsKey(pns))
                {
                    if (data[pns].BadWords.Count > 0)
                    {
                        LulzBot.Say(chan, String.Format("<b>&raquo; I have {0} word{1} for that channel:</b><br/> &middot; <b>[</b>{2}<b>]</b>", data[pns].BadWords.Count, data[pns].BadWords.Count == 1 ? "" : "s", String.Join("<b>]</b>, <b>[</b>", data[pns].BadWords)));
                    }
                    else LulzBot.Say(chan, "<b>&raquo; There are no words in the database for that channel.</b>");
                }
                else LulzBot.Say(chan, "<b>&raquo; BadWords is not turned on for that channel.</b>");
            }
            else if ((arg == "add" || arg == "del") && args.Length == 4)
            {
                String word = args[3].ToLower();
                
                if (data.ContainsKey(pns))
                {
                    if (arg == "add")
                    {
                        if (!data[pns].BadWords.Contains(word))
                        {
                            var cd = data[pns];
                            cd.BadWords.Add(word);
                            data[pns] = cd;
                            
                            Save();
                            
                            LulzBot.Say(chan, String.Format("<b>&raquo; The word '{0}' has been added to the database for {1}.</b>", word, ns));
                        }
                        else LulzBot.Say(chan, "<b>&raquo; That word is already in the list for that channel.</b>");
                    }
                    else
                    {
                        if (data[pns].BadWords.Contains(word))
                        {
                            var cd = data[pns];
                            cd.BadWords.Remove(word);
                            data[pns] = cd;
                            
                            Save();
                            
                            LulzBot.Say(chan, String.Format("<b>&raquo; The word '{0}' has been removed to the database for {1}.</b>", word, ns));
                        }
                        else LulzBot.Say(chan, "<b>&raquo; That word is not in the list for that channel.</b>");
                    }
                }
                else LulzBot.Say(chan, "<b>&raquo; BadWords is not turned on for that channel.</b>");
            }
            else LulzBot.Say(chan, helpmsg);
        }
        else LulzBot.Say(chan, helpmsg);
    }
}
