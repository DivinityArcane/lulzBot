using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using lulzbot;
using lulzbot.Extensions;

[ExtensionInfo("Games", "DivinityArcane", "1.0")]
public class Extension
{
    private static String[] eightball_answers = new String[20] {"It is certain.","It is decidedly so.","Without a doubt.","Yes - definitely.","You may rely on it.","As I see it, yes.","Most likely.","Outlook good.","Yes.","Signs point to yes.","Reply hazy, try again.","Ask again later.","Better not tell you now.","Cannot predict now.","Concentrate and ask again.","Don't count on it.","My reply is no.","My sources say no.","Outlook not so good.","Very doubtful."};
    private static String[] fortunes = new String[291] {"Welcome is a powerful word.","A dubious friend may be an enemy in camouflage.","A feather in the hand is better than a bird in the air. ","A fresh start will put you on your way.","A friend asks only for your time not your money.","A friend is a present you give yourself.","A gambler not only will lose what he has, but also will lose what he doesn't have.","A golden egg of opportunity falls into your lap this month.","A good time to finish up old tasks. ","A hunch is creativity trying to tell you something.","A light heart carries you through all the hard times.","A new perspective will come with the new year. ","A person is never to old to learn. ","A person of words and not deeds is like a garden full of weeds.","A pleasant surprise is waiting for you.","A smile is your personal welcome mat.","A smooth long journey! Great expectations.","A soft voice may be awfully persuasive.","A truly rich life contains love and art in abundance.","Accept something that you cannot change, and you will feel better.","Adventure can be real happiness.","Advice is like kissing. It costs nothing and is a pleasant thing to do.","Advice, when most needed, is least heeded.","All the effort you are making will ultimately pay off.","All the troubles you have will pass away very quickly.","All will go well with your new project.","All your hard work will soon pay off.","Allow compassion to guide your decisions.","An agreeable romance might begin to take on the appearance.","An important person will offer you support.","An inch of time is an inch of gold.","Be careful or you could fall for some tricks today.","Beauty in its various forms appeals to you. ","Because you demand more from yourself, others respect you deeply.","Believe in yourself and others will too.","Believe it can be done.","Better ask twice than lose yourself once.","Carve your name on your heart and not on marble.","Change is happening in your life, so go with the flow!","Competence like yours is underrated.","Congratulations! You are on your way.","Could I get some directions to your heart? ","Courtesy begins in the home.","Courtesy is contagious.","Curiosity kills boredom. Nothing can kill curiosity.","Dedicate yourself with a calm mind to the task at hand.","Depart not from the path which fate has you assigned.","Determination is what you need now.","Disbelief destroys the magic.","Distance yourself from the vain.","Do not be intimidated by the eloquence of others.","Do not let ambitions overshadow small success.","Do not make extra work for yourself.","Do not underestimate yourself. Human beings have unlimited potentials.","Don't be discouraged, because every wrong attempt discarded is another step forward.","Don't confuse recklessness with confidence. ","Don't just spend time. Invest it.","Don't just think, act!","Don't let friends impose on you, work calmly and silently.","Don't let the past and useless detail choke your existence.","Don't let your limitations overshadow your talents.","Don't worry; prosperity will knock on your door soon.","Each day, compel yourself to do something you would rather not do.","Education is the ability to meet life's situations.","Emulate what you admire in your parents. ","Emulate what you respect in your friends.","Every flower blooms in its own sweet time.","Every wise man started out by asking many questions.","Everyday in your life is a special occasion.","Failure is the chance to do better next time.","Feeding a cow with roses does not get extra appreciation.","For hate is never conquered by hate. Hate is conquered by love.","Fortune Not Found: Abort, Retry, Ignore?","From listening comes wisdom and from speaking repentance.","From now on your kindness will lead you to success.","Get your mind set — confidence will lead you on.","Get your mind set…confidence will lead you on.","Go take a rest; you deserve it.","Good news will be brought to you by mail.","Good news will come to you by mail.","Good to begin well, better to end well.","Happiness begins with facing life with a smile and a wink.","Happiness will bring you good luck.","Happy life is just in front of you.","Hard words break no bones, fine words butter no parsnips.","Have a beautiful day.","He who expects no gratitude shall never be disappointed. ","He who knows he has enough is rich.","Help! I'm being held prisoner in a chinese bakery!","How you look depends on where you go.","I learn by going where I have to go.","If a true sense of value is to be yours it must come through service.","If certainty were truth, we would never be wrong.","If you continually give, you will continually have.","If you look in the right places, you can find some good offerings.","If you think you can do a thing or think you can't do a thing, you're right.","If your desires are not extravagant, they will be granted.","If your desires are not to extravagant they will be granted. ","In order to take, one must first give.","In the end all things will be known.","It could be better, but its[sic] good enough.","It is better to deal with problems before they arise.","It is honorable to stand up for what is right, however unpopular it seems.","It is worth reviewing some old lessons.","It takes courage to admit fault.","It's time to get moving. Your spirits will lift accordingly.","Keep your face to the sunshine and you will never see shadows.","Let the world be filled with tranquility and goodwill.","Listen not to vain words of empty tongue.","Listen to everyone. Ideas come from everywhere.","Living with a commitment to excellence shall take you far.","Long life is in store for you.","Love is a warm fire to keep the soul warm.","Love is like sweet medicine, good to the last drop.","Love lights up the world.","Love truth, but pardon error. ","Man is born to live and not prepared to live.","Many will travel to hear you speak.","Meditation with an old enemy is advised.","Miles are covered one step at a time.","Nature, time and patience are the three great physicians.","Never fear! The end of something marks the start of something new.","New ideas could be profitable.","New people will bring you new realizations, especially about big issues. ","No one can walk backwards into the future.","Now is a good time to buy stock.","Now is the time to go ahead and pursue that love interest!","Now is the time to try something new","Now is the time to try something new.","Others can help you now.","Pennies from heaven find their way to your doorstep this year!","People are attracted by your Delicate[sic] features.","People find it difficult to resist your persuasive manner.","Perhaps you've been focusing too much on saving.","Physical activity will dramatically improve your outlook today.","Place special emphasis on old friendship.","Please visit us at www.wontonfood.com","Practice makes perfect.","Protective measures will prevent costly disasters.","Put your mind into planning today. Look into the future.","Remember to share good fortune as well as bad with your friends.","Rest has a peaceful effect on your physical and emotional health.","Resting well is as important as working hard.","Romance moves you in a new direction.","Savor your freedom — it is precious.","Say hello to others. You will have a happier day.","Self-knowledge is a life long process.","Share your joys and sorrows with your family.","Sloth makes all things difficult; industry all easy.","Small confidences mark the onset of a friendship.","Society prepares the crime; the criminal commits it.","Someone you care about seeks reconciliation.","Soon life will become more interesting.","Stand tall. Don't look down upon yourself. ","Stop searching forever, happiness is just next to you.","Success is a journey, not a destination.","Success is going from failure to failure without loss of enthusiasm.","Take care and sensitivity you show towards others will return to you.","Take the high road.","The austerity you see around you covers the richness of life like a veil.","The best prediction of future is the past.","The change you started already have far-reaching effects. Be ready.","The change you started already have far-reaching effects. Be ready.","The first man gets the oyster, the second man gets the shell.","The harder you work, the luckier you get.","The night life is for you.","The one that recognizes the illusion does not act as if it is real.","The only people who never fail are those who never try.","The person who will not stand for something will fall for anything.","The philosophy of one century is the common sense of the next.","The saints are the sinners who keep on trying.","The secret to good friends is no secret to you. ","The small courtesies sweeten life, the greater ennoble it.","The smart thing to do is to begin trusting your intuitions.","The strong person understands how to withstand substantial loss.","The sure way to predict the future is to invent it.","The truly generous share, even with the undeserving.","The value lies not within any particular thing, but in the desire placed on that thing.","The weather is wonderful. ","There is no mistake so great as that of being always right.","There is no wisdom greater than kindness. ","There is not greater pleasure than seeing your lived ones prosper.","There's no such thing as an ordinary cat.","Things don't just happen; they happen just.","Those who care will make the effort.","Time and patience are called for many surprises await you!.","Time is precious, but truth is more precious than time","To know oneself, one should assert oneself.","Today is the conserve yourself, as things just won't budge.","Today, your mouth might be moving but no one is listening.","Tonight you will be blinded by passion.","Use your eloquence where it will do the most good.","Welcome change.","Well done is better than well said.","What's hidden in an empty box?","What's yours in mine, and what's mine is mine.","When your heart is pure, your mind is clear.","Wish you happiness.","You always bring others happiness.","You are a person of another time.","You are a talented storyteller. ","You are admired by everyone for your talent and ability.","You are almost there.","You are busy, but you are happy.","You are generous to an extreme and always think of the other fellow.","You are going to have some new clothes. ","You are in good hands this evening.","You are modest and courteous.","You are never selfish with your advice or your help.","You are next in line for promotion in your firm.","You are offered the dream of a lifetime. Say yes!","You are open-minded and quick to make new friends. ","You are solid and dependable.","You are soon going to change your present line of work.","You are talented in many ways.","You are the master of every situation. ","You are very expressive and positive in words, act and feeling.","You are working hard.","You begin to appreciate how important it is to share your personal beliefs.","You desire recognition and you will find it.","You have a deep appreciation of the arts and music.","You have a deep interest in all that is artistic.","You have a friendly heart and are well admired. ","You have a shrewd knack for spotting insincerity.","You have a yearning for perfection.","You have an active mind and a keen imagination.","You have an ambitious nature and may make a name for yourself.","You have an unusual equipment for success, use it properly.","You have exceeded what was expected.","You have the power to write your own fortune.","You have yearning for perfection.","You know where you are going and how to get there.","You look pretty.","You love challenge.","You love chinese food.","You make people realize that there exist other beauties in the world.","You never hesitate to tackle the most difficult problems. ","You seek to shield those you love and like the role of provider. ","You should be able to make money and hold on to it.","You should be able to undertake and complete anything.","You understand how to have fun with others and to enjoy your solitude.","You will always be surrounded by true friends.","You will always get what you want through your charm and personality.","You will always have good luck in your personal affairs.","You will be a great success both in the business world and society. ","You will be blessed with longevity.","You will be successful in your work.","You will be traveling and coming into a fortune.","You will be unusually successful in business.","You will become a great philanthropist in your later years.","You will become more and more wealthy.","You will enjoy good health.","You will enjoy good health; you will be surrounded by luxury.","You will find great contentment in the daily, routine activities.","You will have a fine capacity for the enjoyment of life.","You will have gold pieces by the bushel.","You will inherit a large sum of money.","You will make change for the better.","You will soon be surrounded by good friends and laughter.","You will take a chance in something in near future.","You will travel far and wide, both pleasure and business.","You will travel far and wide,both pleasure and business.","Your abilities are unparalleled.","Your ability is appreciated.","Your ability to juggle many tasks will take you far.","Your biggest virtue is your modesty.","Your character can be described as natural and unrestrained.","Your difficulties will strengthen you.","Your dreams are never silly; depend on them to guide you.","Your dreams are worth your best efforts to achieve them.","Your energy returns and you get things done.","Your family is young, gifted and attractive.","Your first love has never forgotten you.","Your happiness is before you, not behind you! Cherish it.","Your hard work will payoff today.","Your heart will always make itself known through your words.","Your home is the center of great love.","Your ideals are well within your reach.","Your infinite capacity for patience will be rewarded sooner or later.","Your leadership qualities will be tested and proven.","Your life will be happy and peaceful.","Your life will get more and more exciting.","Your love life will be happy and harmonious.","Your love of music will be an important part of your life.","Your loyalty is a virtue, but not when it's wedded with blind stubbornness.","Your mind is creative, original and alert.","Your mind is your greatest asset.","Your quick wits will get you out of a tough situation.","Your success will astonish everyone. ","Your talents will be recognized and suitably rewarded.","Your work interests can capture the highest status or prestige."};
    private static String[] rr_fails = new String[4] {"*BAM* You fall flat to the floor, lifeless.","*BAM* The gun fires, but you were too scared flung it away from your head. The bullet fired off in the other direction, killing the one you loved most.","*BAM* The gun fires, but kills both you and the one you love.","*thud* You drop the gun and run as fast as you can, like the coward you are."};
    private static String[] rr_multi_fails = new String[4] {"*BAM* {0} fall flat to the floor, lifeless.","*BAM* The gun goes off, killing {0}.","*BAM* The gun fires! {0} blew their brains out.","*BAM* {0} drop to the floor as their brains hit the wall."};
    private static String[] rr_wins = new String[4] {"*click* It seems your luck has saved you. This time.","*snap* The gun jams, narrowly saving your life at the last second.","*click* You got lucky, and survived this time.","*click* You survive this round, but what about the next?"};
    private static String[] rr_multi_wins = new String[4] {"*click* {0} survived, somehow.","*click* For some odd reason, {0} survived.","*click* The chamber is empty, {0} survived.","*click* {0} barely make it, surviving to the next round."};
    private static Dictionary<String, String> vend_data;
    private static List<String> insult_data;
    private static Random rand = new Random();

    private void LoadVend()
    {
        vend_data = Storage.Load<Dictionary<String, String>>("vend");

        if (vend_data == null)
            vend_data = new Dictionary<String, String>();
    }

    private void SaveVend()
    {
        Storage.Save("vend", vend_data);
    }

    private void LoadInsults()
    {
        insult_data = Storage.Load<List<String>>("insults");

        if (insult_data == null)
            insult_data = new List<String>();
    }

    private void SaveInsults()
    {
        Storage.Save("insults", insult_data);
    }
    
    [BindCommand("8ball", "Simple 8Ball command.", Privs.Guest, "[trig]8ball question")]
    public void cmd_8ball(String chan, String msg, String[] args, String from)
    {
        String helpmsg = String.Format("<b>&raquo; Usage:</b> {0}8ball question", LulzBot.Trigger);
            
        if (args.Length == 1)
        {
            LulzBot.Say(chan, helpmsg);
        }
        else
        {
            String question = msg.Substring(6);
            int ri = rand.Next() % eightball_answers.Length;
            String reply = eightball_answers[ri];

            LulzBot.Say(chan, String.Format("<b>&raquo; You asked:</b> <i>\"{0}\"</i><br/><b>&raquo; My reply:</b> <i>\"{1}\"</i>", question, reply));
        }
    }
    
    [BindCommand("fortune", "Simple fortune cookie command.", Privs.Guest, "[trig]fortune")]
    public void cmd_fortune(String chan, String msg, String[] args, String from)
    {
        int ri = new Random().Next() % fortunes.Length;
        String reply = fortunes[ri];

        LulzBot.Say(chan, String.Format("<b>&raquo; Your fortune is:</b> <i>\"{0}\"</i>", reply));
    }
    
    [BindCommand("roll", "Simple dice roll command.", Privs.Guest, "[trig]roll #d#")]
    [BindCommand("dice", "Simple dice roll command.", Privs.Guest, "[trig]dice #d#")]
    public void cmd_roll(String chan, String msg, String[] args, String from)
    {
        String helpmsg = String.Format("<b>&raquo; Usage:</b> {0}roll #d#", LulzBot.Trigger);
            
        if (args.Length == 1 || !args[1].Contains("d"))
        {
            LulzBot.Say(chan, helpmsg);
        }
        else
        {
            String[] input = args[1].Split(new char[] {'d'});

            if (input[0].Length < 1 || input[1].Length < 1)
            {
                LulzBot.Say(chan, helpmsg);
                return;
            }
            
            int dice = 0, sides = 0;
            bool ok = false;

            ok = int.TryParse(input[0], out dice);

            if (!ok || dice <= 0 || dice > 25)
            {
                LulzBot.Say(chan, "<b>&raquo; Invalid number of dice. You're allowed 1-25 dice.</b>");
                return;
            }

            ok = int.TryParse(input[1], out sides);

            if (!ok || sides <= 0 || sides > 2500)
            {
                LulzBot.Say(chan, "<b>&raquo; Invalid number of sides. You're allowed 1-2500 sides.</b>");
                return;
            }

            int sum = 0;

            if (dice == 1)
                sum = rand.Next() % sides;
            else
            {
                for (int i = 0; i < dice; i++)
                    sum += rand.Next() % sides;
            }
            
            LulzBot.Say(chan, String.Format("<b>&raquo; You rolled {0} and got:</b> {1}", args[1], sum));
        }
    }
    
    [BindCommand("vender", "Vending machine management command.", Privs.Members, "[trig]vender list<br/>[trig]vender add/del item")]
    public void cmd_vender(String chan, String msg, String[] args, String from)
    {
        if (vend_data == null)
            LoadVend();
            
        String helpmsg = String.Format("<b>&raquo; Usage:</b><br/>{0}vender list<br/>{0}vender add/del item", " &middot; " + LulzBot.Trigger);
            
        if (args.Length < 2)
        {
            LulzBot.Say(chan, helpmsg);
        }
        else
        {
            String arg = args[1];

            if (args.Length >= 3)
            {
                String item = msg.Substring(11);

                if (arg == "add")
                {
                    if (vend_data.ContainsKey(item.ToLower()))
                    {
                        LulzBot.Say(chan, "<b>&raquo; The machine already stocks item:</b> " + item);
                    }
                    else
                    {
                        vend_data.Add(item.ToLower(), item);
                        SaveVend();
                        LulzBot.Say(chan, "<b>&raquo; Item added to machine:</b> " + item);
                    }
                }
                else if (arg == "del")
                {
                    if (!vend_data.ContainsKey(item.ToLower()))
                    {
                        LulzBot.Say(chan, "<b>&raquo; The machine does not stock item:</b> " + item);
                    }
                    else
                    {
                        vend_data.Remove(item.ToLower());
                        SaveVend();
                        LulzBot.Say(chan, "<b>&raquo; Item removed from machine:</b> " + item);
                    }
                }
                else LulzBot.Say(chan, helpmsg);
            }
            else if (arg == "list")
            {
                if (vend_data.Count == 0)
                    LulzBot.Say(chan, "<b>&raquo; This machine is empty.</b>");
                else
                    LulzBot.Say(chan, String.Format("<b>&raquo; This machine vends the following items:</b> <b>[</b>{0}<b>]</b>", String.Join("<b>]</b>, <b>[</b>", vend_data.Values)));
            }
            else LulzBot.Say(chan, helpmsg);
        }
    }
    
    [BindCommand("vend", "Vending machine command.", Privs.Guest, "[trig]vend")]
    public void cmd_vend(String chan, String msg, String[] args, String from)
    {
        if (vend_data == null)
            LoadVend();
            
        if (vend_data.Count == 0)
            LulzBot.Say(chan, "<b>&raquo; The machine is currently empty. Wait until it gets stocked!</b>");
        else
        {
            bool jammed = (rand.Next() % (vend_data.Count * 3.5)) < vend_data.Count;

            if (jammed)
                LulzBot.Say(chan, "<b>&raquo; Sorry, it seems the machine has jammed! You lost your money!</b>");
            else
            {
                int ri = rand.Next() % vend_data.Count;

                LulzBot.Say(chan, "<b>&raquo; You inserted your money, heard some banging, and got:</b> " + vend_data.ElementAt(ri).Value);
            }
        }
    }
    
    [BindCommand("throw", "Rock-Paper-Scissors command.", Privs.Members, "[trig]throw rock/paper/scissors")]
    public void cmd_throw(String chan, String msg, String[] args, String from)
    {
        String helpmsg = String.Format("<b>&raquo; Usage:</b> {0}throw rock/paper/scissors", LulzBot.Trigger);
            
        if (args.Length < 2)
        {
            LulzBot.Say(chan, helpmsg);
        }
        else
        {
            String arg = args[1];

            if (arg != "rock" && arg != "paper" && arg != "scissors")
            {
                LulzBot.Say(chan, helpmsg);
                return;
            }

            int ri = rand.Next() % 3;

            String choice   = (ri == 0 ? "rock" : ri == 1 ? "paper" : "scissors");
            bool player_won = false;

            if (arg == choice)
                LulzBot.Say(chan, "<b>&raquo; It was a draw!</b>");
            else
            {
                if (arg == "rock")
                    player_won = (choice == "scissors" ? true : false);
                else if (arg == "paper")
                    player_won = (choice == "rock" ? true : false);
                else if (arg == "scissors")
                    player_won = (choice == "paper" ? true : false);

                if (player_won)
                    LulzBot.Say(chan, "<b>&raquo; You won!</b>");
                else
                    LulzBot.Say(chan, "<b>&raquo; You lost!</b>");
            }
        }
    }
    
    [BindCommand("coin", "Coin-flip command.", Privs.Guest, "[trig]coin")]
    [BindCommand("flip", "Coin-flip command.", Privs.Guest, "[trig]flip")]
    public void cmd_coin(String chan, String msg, String[] args, String from)
    {
        int ri = rand.Next() % 2;
        LulzBot.Say(chan, String.Format("<b>&raquo; You flipped a coin, and got {0}!</b>", ri == 0 ? "heads" : "tails"));
    }
    
    [BindCommand("rr", "Russian roulette command.", Privs.Guest, "[trig]rr number_of_bullets <i>person1 person2 ...</i>")]
    public void cmd_rr(String chan, String msg, String[] args, String from)
    {
        String helpmsg = String.Format("<b>&raquo; Usage:</b><br/>{0}rr #bullets<br/>{0}rr #bullets person1 person2 ...", " &middot; " + LulzBot.Trigger);
            
        if (args.Length < 2)
        {
            LulzBot.Say(chan, helpmsg);
        }
        else
        {
            int bullets = 0;

            bool ok = int.TryParse(args[1], out bullets);

            if (!ok || bullets < 1 || bullets > 6)
            {
                LulzBot.Say(chan, "<b>&raquo; Invalid amount of bullets. Must be within 1-6.</b>");
                return;
            }

            if (args.Length <= 3)
            {
                int ri = rand.Next() % (bullets + 1);
                String res;

                if (ri <= (bullets / 2) || bullets == 6)
                {
                    res = rr_fails[rand.Next() % rr_fails.Length];
                }
                else
                {
                    res = rr_wins[rand.Next() % rr_wins.Length];
                }
                
                LulzBot.Say(chan, String.Format("<b>&raquo; {0}You place {1} bullet{2} into the gun, roll the barrel, and place the gun to your head. You slowly pull the trigger...</b> {3}", args.Length == 3 ? args[2] + ": " : "", bullets, bullets == 1 ? "" : "s", res));
            }
            else
            {
                String[] people = new String[args.Length - 2];
                Array.Copy(args, 2, people, 0, people.Length);

                List<String> dead = new List<String>(), alive = new List<String>();

                foreach (String person in people)
                {
                    int ri = rand.Next() % (bullets + 1);

                    if (ri <= (bullets / 2) || bullets == 6)
                        dead.Add(person);
                    else alive.Add(person);
                }

                String res = "";

                if (dead.Count > 0)
                {
                    String thedead = dead[0];

                    if (dead.Count > 2)
                    {
                        for (int i = 1; i < dead.Count - 1; i++)
                            thedead += ", " + dead[i];
                        thedead += " and " + dead[dead.Count - 1];
                    }
                    else if (dead.Count == 2)
                        thedead += " and " + dead[1];
                    
                    res += String.Format(rr_multi_fails[rand.Next() % rr_multi_fails.Length], thedead);
                }

                if (alive.Count > 0)
                {
                    String theliving = alive[0];

                    if (alive.Count > 2)
                    {
                        for (int i = 1; i < alive.Count - 1; i++)
                            theliving += ", " + alive[i];
                        theliving += " and " + alive[alive.Count - 1];
                    }
                    else if (alive.Count == 2)
                        theliving += " and " + alive[1];
                    
                    res += (dead.Count > 0 ? " " : "") + String.Format(rr_multi_wins[rand.Next() % rr_multi_wins.Length], theliving);
                }

                LulzBot.Say(chan, String.Format("<b>&raquo; You place {0} bullet{1} into the gun, roll the barrel, and place the gun to your head. You slowly pull the trigger...</b> {2}", bullets, bullets == 1 ? "" : "s", res));
            }
        }
    }
    
    [BindCommand("insults", "Insults management command.", Privs.Members, "[trig]insults list<br/>[trig]insults add insult_text<br/>[trig]insult del #id<br/><br/><i>[who] will be replaced with the targets name.</i>")]
    public void cmd_insults(String chan, String msg, String[] args, String from)
    {
        if (insult_data == null)
            LoadInsults();
            
        String helpmsg = String.Format("<b>&raquo; Usage:</b><br/>{0}insults list<br/>{0}insults add insult_text<br/>{0}insults del #id<br/><br/><i>You can use <b>[who]</b> in the insult text, and it will be replaced with the target's name automatically.</i>", " &middot; " + LulzBot.Trigger);
            
        if (args.Length < 2)
        {
            LulzBot.Say(chan, helpmsg);
        }
        else
        {
            String arg = args[1];

            if (args.Length >= 3)
            {
                if (arg == "add")
                {
                    String item = msg.Substring(12);
                    insult_data.Add(item);
                    SaveInsults();
                    LulzBot.Say(chan, "<b>&raquo; Insult added:</b> " + item);
                }
                else if (arg == "del")
                {
                    int id = -1;

                    bool ok = int.TryParse(args[2], out id);

                    if (!ok || id < 1 || id > insult_data.Count)
                    {
                        LulzBot.Say(chan, "<b>&raquo; The insult id must be a valid number and exist in the list!</b>");
                        return;
                    }

                    id -= 1;

                    String item = insult_data[id];
                    
                    insult_data.RemoveAt(id);
                    SaveInsults();
                    LulzBot.Say(chan, "<b>&raquo; Insult removed:</b> " + item);
                }
                else LulzBot.Say(chan, helpmsg);
            }
            else if (arg == "list")
            {
                if (insult_data.Count == 0)
                    LulzBot.Say(chan, "<b>&raquo; There are no insults in the list.</b>");
                else
                {
                    String list = "<b>&raquo; The following insults are in the list:</b>";
                    for (int i = 0; i < insult_data.Count; i++)
                    {
                        list += String.Format("<br/><b> &middot; #{0}:</b> <i>{1}</i>", i + 1, insult_data[i]);
                    }
                    LulzBot.Say(chan, list);
                }
            }
            else LulzBot.Say(chan, helpmsg);
        }
    }
    
    [BindCommand("insult", "Insult command.", Privs.Guest, "[trig]insult target_username")]
    public void cmd_insult(String chan, String msg, String[] args, String from)
    {
        if (insult_data == null)
            LoadInsults();
            
        if (insult_data.Count == 0)
            LulzBot.Say(chan, "<b>&raquo; There are no insults in the list. Add some with the <i>insults</i> command!</b>");
        else
        {
            if (args.Length < 2)
            {
                LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}insult username/target", LulzBot.Trigger));
                return;
            }

            // Allow for spaces, instead of just usernames.
            String who = msg.Substring(7);

            int id = rand.Next() % insult_data.Count;
            String insult = insult_data[id];
            insult = insult.Replace("[who]", who);

            LulzBot.Say(chan, "<b>&raquo;</b> " + insult);
        }
    }
    
    [BindCommand("hlds", "HLDS/SRCDS server query command.", Privs.Members, "[trig]hlds host<i>:port -players/-cvars</i>")]
    public void cmd_hlds(String chan, String msg, String[] args, String from)
    {
        if (args.Length == 1)
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage: </b>{0}hlds host<i><code>[:port] [-players|-cvars]</code></i>", LulzBot.Trigger));
        else
        {
            int port = 27015, pos = 0;
			String host = "";
			
			if ((pos = args[1].IndexOf(":")) != -1)
			{
				host = args[1].Substring(0, pos);
				
				if (!int.TryParse(args[1].Substring(pos + 1), out port))
					port = 27015;
			}
			else host = args[1];

            try
            {
                var q = new SRCDSQuery.ServerQuery(host+':'+port);

                if (q.Latency <= 0)
                    LulzBot.Say(chan, "<b>&raquo; Request timed out. Is it a valid host with a game running?</b>");
                else
                {
                    String output = "<b>&raquo; Server Query for "+host+':'+port+"</b>";
                    
                    if (args.Length == 3 && args[2] == "-players" && q.Players.Data != null)
                    {
                        if (q.ServerInfo.Players > 0 || q.ServerInfo.Bots > 0)
                        {
                            output += "<br/><br/> <b>&raquo; Player Info:</b>";
                            foreach (SRCDSQuery.PlayerInfo info in q.Players.Data)
                            {
                                output += "<br/><b>&middot; " + info.Name + " - Score:</b> " + info.Score + " - <b>Online:</b> " + Tools.FormatTime((int)info.Online);
                            }
                        }
                        else output += "<br/><b>&raquo; No players are online or the server returned no data.</b>";
                    }
                    else if (args.Length == 3 && args[2] == "-cvars" && q.Cvars.Data != null)
                    {
                        if (q.Cvars.Data.Count > 0)
                        {
                            output += "<br/><br/> <b>&raquo; Cvar Info:</b>";
                            foreach (SRCDSQuery.Cvar info in q.Cvars.Data)
                            {
                                output += "<br/><b>&middot; " + info.Name + ":</b> <code>" + info.Value + "</code>";
                            }
                        }
                        else output += "<br/><b>&raquo; No cvars were public or the server returned no data.</b>";
                    }
                    else
                    {
                        output += "<br/><b> &middot; Server Name:</b> " + q.ServerInfo.ServerName;
                        output += "<br/><b> &middot; Server Latency:</b> " + q.Latency;
                        output += "<br/><b> &middot; Server Type:</b> " + q.ServerInfo.Type.ToString();
                        output += "<br/><b> &middot; Server Environment:</b> " + q.ServerInfo.System.ToString();
                        output += "<br/><b> &middot; Server Version:</b> " + q.ServerInfo.Version;
                        output += "<br/><b> &middot; Server Protocol:</b> " + q.ServerInfo.Protocol;
                        output += "<br/><b> &middot; Game Name:</b> " + q.ServerInfo.GameName;
                        output += "<br/><b> &middot; Game AppID:</b> " + q.ServerInfo.AppID;
                        output += "<br/><b> &middot; Game Folder:</b> " + q.ServerInfo.Folder;
                        output += "<br/><b> &middot; Map Name:</b> " + q.ServerInfo.MapName;
                        output += "<br/><b> &middot; Players Online/Max:</b> " + q.ServerInfo.Players + '/' + q.ServerInfo.MaxPlayers;
                        output += "<br/><b> &middot; Bots Online:</b> " + q.ServerInfo.Bots;
                        output += "<br/><b> &middot; Private Server:</b> " + q.ServerInfo.Private.ToString();
                        output += "<br/><b> &middot; Secure Server:</b> " + q.ServerInfo.VACSecure.ToString();
                    }
                    
                    LulzBot.Say(chan, output);
                }
            }
            catch (Exception E)
            {
                LulzBot.Say(chan, "<b>&raquo; Failed to query the server:</b> " + E.Message);
                return;
            }
        }
    }
    
    [BindCommand("mc", "Minecraft server query command.", Privs.Members, "[trig]mc host<i>:port -players</i>")]
    public void cmd_mc(String chan, String msg, String[] args, String from)
    {
        if (args.Length == 1)
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage: </b>{0}mc host<i><code>[:port] [-players]</code></i>", LulzBot.Trigger));
        else
        {
            int port = 25565, pos = 0;
			String host = "";
			
			if ((pos = args[1].IndexOf(":")) != -1)
			{
				host = args[1].Substring(0, pos);
				
				if (!int.TryParse(args[1].Substring(pos + 1), out port))
					port = 25565;
			}
			else host = args[1];

            try
            {
                MCQuery.ServerQuery q = new MCQuery.MCQuery();
				q.Connect(host, port);
				
				if (q == null || !q.Success())
				{
					q = new MCQuery.MCSimpleQuery();
					q.Connect(host, port);
				}

                if (q == null || !q.Success())
                    LulzBot.Say(chan, "<b>&raquo; Request failed or timed out. Is it a valid host with a game running?</b>");
                else
                {
                    String output = "<b>&raquo; Server Query for "+host+':'+port+"</b>";
                    
					var info = q.Info();
					
                    if (args.Length == 3 && args[2] == "-players" && info.Players != null)
                    {
                        if (info.OnlinePlayers > 0)
                        {
                            output += "<br/><br/> <b>&raquo; Player Info:</b>";
                            foreach (var name in info.Players)
                            {
                                output += "<br/><b>&middot; " + name + "</b>";
                            }
                        }
                        else output += "<br/><b>&raquo; No players are online or the server returned no data.</b>";
                    }
                    else
                    {
                        output += "<br/><b> &middot; Server Name:</b> " + info.Name;
                        output += "<br/><b> &middot; Server Latency:</b> " + info.Latency;
                        output += "<br/><b> &middot; Server Version:</b> " + info.Version;
                        output += "<br/><b> &middot; Server Protocol:</b> " + info.Protocol;
						
						if (info.GameID != null && info.GameID.Length > 0)
							output += "<br/><b> &middot; Game ID:</b> " + info.GameID;
						
						if (info.GameType != null && info.GameType.Length > 0)
							output += "<br/><b> &middot; Game Type:</b> " + info.GameType;
						
						if (info.Map != null && info.Map.Length > 0)
							output += "<br/><b> &middot; Map Name:</b> " + info.Map;
							
                        output += "<br/><b> &middot; Players Online/Max:</b> " + info.OnlinePlayers + '/' + info.MaxPlayers;
						
						if (info.Software != null && info.Software.Length > 0)
							output += "<br/><b> &middot; Software:</b> " + info.Software;
							
						if (info.HostIP != null && !info.HostIP.StartsWith("127."))
							output += "<br/><b> &middot; Host IP<i>:</i>Port:</b> " + info.HostIP + ':' + info.HostPort;
                    }
                    
                    LulzBot.Say(chan, output);
                }
            }
            catch (Exception E)
            {
                LulzBot.Say(chan, "<b>&raquo; Failed to query the server:</b> " + E.Message);
                return;
            }
        }
    }
}
