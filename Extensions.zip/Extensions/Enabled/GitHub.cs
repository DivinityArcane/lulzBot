using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using lulzbot;
using lulzbot.Extensions;

[ExtensionInfo("GitHub", "DivinityArcane", "1.0")]
public class Extension
{
    public JArray GrabJsonArray(String type, String query, String extra = "")
    {
        try
        {
            String url, body;
            bool unescape = false;
            query = Uri.EscapeDataString(query);
			
            switch (type)
            {
                case "commits":
                    url = @"https://api.github.com/repos/" + query + "/commits?per_page=5";
                    break;
                    
                case "issues":
                    url = @"https://api.github.com/repos/" + query + extra + "&per_page=5";
                    break;
                
                default:
                    return null;
            }

            body = Tools.GrabPage(url, accept:"text/plain;q=0.9,*/*;q=0.8");
			
            if (unescape)
                body = Regex.Unescape(body);
				
            return (body == null ? null : JArray.Parse(body));
        }
        catch { return null; }
    }

    public struct CommitInfo
    {
        public string Author;
        public string Username;
        public string SHA;
        public string Date;
        public string Message;
    }

    public struct IssueInfo
    {
        public string Author;
        public string Number;
        public string Title;
        public string Assignee;
        public string Date;
    }

    public struct ForkInfo
    {
        public string Author;
        public string Title;
        public string Date;
    }
    
    [BindCommand("commits", "GitHub repository commit search.", Privs.Guest)]
    public void cmd_commits(String chan, String msg, String[] args, String from)
    {
        if (args.Length == 3)
        {
			String query = args[1] + "/" + args[2];
            var res = GrabJsonArray("commits", query);

            if (res == null)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }
            
            List<CommitInfo> results = new List<CommitInfo>();
            var res_query =
                from result in res.Children()
                select new CommitInfo() { 
                    Author     = result["commit"]["author"]["name"].ToString(),
                    Username   = result["committer"]["login"].ToString(),
                    Date       = result["commit"]["author"]["date"].ToString(),
                    SHA        = result["sha"].ToString(),
                    Message    = result["commit"]["message"].ToString()
                };

            foreach (var nres in res_query) results.Add(nres);

            if (results.Count <= 0)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }

            String output = String.Format("<b>&raquo; Most recent {0} commit{1} to {2}:</b>", results.Count, results.Count == 1 ? "" : "s", query);

            foreach (CommitInfo result in results) {
                output += String.Format("<br/><br/> &raquo; {0} ago by <a href=\"https://github.com/{1}\"><b>{2}</b></a><br/>", Tools.FormatTime((int)(DateTime.UtcNow - DateTime.Parse(result.Date)).TotalSeconds), result.Username, result.Author);
                output += String.Format("&nbsp;&nbsp;&middot; <i><a href=\"https://github.com/{0}/commit/{1}\">{2}</a></i>", query, result.SHA, result.Message);
            }

            output += String.Format("<br/><br/><sub><i>Click <a href=\"https://github.com/{0}/commits/\">here</a> to view more commits.</i></sub>", query);
            
            LulzBot.Say(chan, output);
        }
        else
        {
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}commits username reponame", LulzBot.Trigger));
        }
    }
    
    [BindCommand("issues", "GitHub repository issue search.", Privs.Guest)]
    public void cmd_issues(String chan, String msg, String[] args, String from)
    {
        if (args.Length >= 3)
        {
			String state = "open";
            
            if (args.Length == 4 && args[3] == "closed")
                state = "closed";
                
            String query = args[1] + "/" + args[2];
                
            var res = GrabJsonArray("issues", query, "/issues?state=" + state);

            if (res == null)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }
            
            List<IssueInfo> results = new List<IssueInfo>();
            var res_query =
                from result in res.Children()
                select new IssueInfo() { 
                    Author     = result["user"]["login"].ToString(),
                    Number     = result["number"].ToString(),
                    Title      = result["title"].ToString(),
                    Assignee   = result["assignee"].ToString().Length < 12 ? "null" : result["assignee"]["login"].ToString(),
                    Date       = result["created_at"].ToString()
                };

            foreach (var nres in res_query) results.Add(nres);

            if (results.Count <= 0)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }

            String output = String.Format("<b>&raquo; Most recent {0} issue{1} to {2}:</b>", results.Count, results.Count == 1 ? "" : "s", query);

            foreach (IssueInfo result in results) {
                output += String.Format("<br/><br/> &raquo; Opened {0} ago by <a href=\"https://github.com/{1}\"><b>{1}</b></a><br/>", Tools.FormatTime((int)(DateTime.UtcNow - DateTime.Parse(result.Date)).TotalSeconds), result.Author);
                output += String.Format("&nbsp;&nbsp;&middot; <i><a href=\"https://github.com/{0}/issue/{1}\">{2}</a></i>", query, result.Number, result.Title);
                if (result.Assignee != "null")
                    output += String.Format("<br/>&nbsp;&nbsp;&middot; <B>Assigned to:</b> <a href=\"https://github.com/{0}\">{0}</a>", result.Assignee);
            }

            output += String.Format("<br/><br/><sub><i>Click <a href=\"https://github.com/{0}/issues/\">here</a> to view more issues.</i></sub>", query);
            
            LulzBot.Say(chan, output);
        }
        else
        {
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}issues username reponame <i>[closed]</i>", LulzBot.Trigger));
        }
    }
}
