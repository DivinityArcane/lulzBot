using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Security.Cryptography;
using Newtonsoft.Json.Linq;
using lulzbot;
using lulzbot.Extensions;

[ExtensionInfo("Hash", "DivinityArcane", "1.0")]
public class Extension
{
    private byte[] TB(string data)
    {
        return Encoding.UTF8.GetBytes(data);
    }
    
    private string FB(byte[] data)
    {
        var sb = new StringBuilder();
        
        for (int i = 0; i < data.Length; i++) { sb.Append(data[i].ToString("x2")); }
        
        return sb.ToString();
    }

    [BindCommand("sha1", "Return the SHA1 hash of the specified input string.", Privs.Guest, "[trig]sha1 plaintext")]
    public void cmd_sha1(String chan, String msg, String[] args, String from)
    {
        if (args.Length > 1)
        {
            var ipt = TB(msg.Substring(args[0].Length + 1));
            var opt = FB(SHA1.Create().ComputeHash(ipt));
            
            LulzBot.Say(chan, "<b>&raquo; Result:</b> " + opt);
        }
        else LulzBot.Say(chan, "<b>&raquo; Usage:</b> " + LulzBot.Trigger + "sha1 input");
    }

    [BindCommand("sha256", "Return the SHA256 hash of the specified input string.", Privs.Guest, "[trig]sha256 plaintext")]
    public void cmd_sha256(String chan, String msg, String[] args, String from)
    {
        if (args.Length > 1)
        {
            var ipt = TB(msg.Substring(args[0].Length + 1));
            var opt = FB(SHA256.Create().ComputeHash(ipt));
            
            LulzBot.Say(chan, "<b>&raquo; Result:</b> " + opt);
        }
        else LulzBot.Say(chan, "<b>&raquo; Usage:</b> " + LulzBot.Trigger + "sha256 input");
    }

    [BindCommand("sha384", "Return the SHA384 hash of the specified input string.", Privs.Guest, "[trig]sha384 plaintext")]
    public void cmd_sha384(String chan, String msg, String[] args, String from)
    {
        if (args.Length > 1)
        {
            var ipt = TB(msg.Substring(args[0].Length + 1));
            var opt = FB(SHA384.Create().ComputeHash(ipt));
            
            LulzBot.Say(chan, "<b>&raquo; Result:</b> " + opt);
        }
        else LulzBot.Say(chan, "<b>&raquo; Usage:</b> " + LulzBot.Trigger + "sha384 input");
    }

    [BindCommand("sha512", "Return the SHA512 hash of the specified input string.", Privs.Guest, "[trig]sha512 plaintext")]
    public void cmd_sha512(String chan, String msg, String[] args, String from)
    {
        if (args.Length > 1)
        {
            var ipt = TB(msg.Substring(args[0].Length + 1));
            var opt = FB(SHA512.Create().ComputeHash(ipt));
            
            LulzBot.Say(chan, "<b>&raquo; Result:</b> " + opt);
        }
        else LulzBot.Say(chan, "<b>&raquo; Usage:</b> " + LulzBot.Trigger + "sha512 input");
    }

    [BindCommand("md160", "Return the RIPE MD160 hash of the specified input string.", Privs.Guest, "[trig]md160 plaintext")]
    public void cmd_md160(String chan, String msg, String[] args, String from)
    {
        if (args.Length > 1)
        {
            var ipt = TB(msg.Substring(args[0].Length + 1));
            var opt = FB(RIPEMD160.Create().ComputeHash(ipt));
            
            LulzBot.Say(chan, "<b>&raquo; Result:</b> " + opt);
        }
        else LulzBot.Say(chan, "<b>&raquo; Usage:</b> " + LulzBot.Trigger + "md160 input");
    }

    [BindCommand("binary", "Return the binary representation of the specified input string.", Privs.Guest, "[trig]binary plaintext")]
    public void cmd_binary(String chan, String msg, String[] args, String from)
    {
        if (args.Length > 1)
        {
            var ipt = TB(msg.Substring(args[0].Length + 1));
            var opt = "";
            
            foreach (byte b in ipt) { opt += Convert.ToString(b, 2); }
            
            LulzBot.Say(chan, "<b>&raquo; Result:</b> " + opt);
        }
        else LulzBot.Say(chan, "<b>&raquo; Usage:</b> " + LulzBot.Trigger + "binary input");
    }
}