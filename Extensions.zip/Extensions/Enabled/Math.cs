using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using lulzbot;
using lulzbot.Extensions;

[ExtensionInfo("Math", "DivinityArcane", "1.0")]
public class Extension
{
    [BindCommand("acos", "Return the angle whose cosine is the specified number.", Privs.Guest)]
    public void cmd_acos(String chan, String msg, String[] args, String from)
    {
        var helpmsg = String.Format("<b>&raquo; Usage:</b> {0}acos number", LulzBot.Trigger);
        
        if (args.Length == 2)
        {
            double x = 0;
            
            if (double.TryParse(args[1], out x))
                LulzBot.Say(chan, "<b>&raquo; Result:</b> " + Math.Acos(x));
            else
                LulzBot.Say(chan, "<b>&raquo; Invalid number.</b>");
        }
        else LulzBot.Say(chan, helpmsg);
    }
    
    [BindCommand("asin", "Return the angle whose sine is the specified number.", Privs.Guest)]
    public void cmd_asin(String chan, String msg, String[] args, String from)
    {
        var helpmsg = String.Format("<b>&raquo; Usage:</b> {0}asin number", LulzBot.Trigger);
        
        if (args.Length == 2)
        {
            double x = 0;
            
            if (double.TryParse(args[1], out x))
                LulzBot.Say(chan, "<b>&raquo; Result:</b> " + Math.Asin(x));
            else
                LulzBot.Say(chan, "<b>&raquo; Invalid number.</b>");
        }
        else LulzBot.Say(chan, helpmsg);
    }
    
    [BindCommand("atan", "Return the angle whose tangent is the specified number.", Privs.Guest)]
    public void cmd_atan(String chan, String msg, String[] args, String from)
    {
        var helpmsg = String.Format("<b>&raquo; Usage:</b> {0}atan number", LulzBot.Trigger);
        
        if (args.Length == 2)
        {
            double x = 0;
            
            if (double.TryParse(args[1], out x))
                LulzBot.Say(chan, "<b>&raquo; Result:</b> " + Math.Atan(x));
            else
                LulzBot.Say(chan, "<b>&raquo; Invalid number.</b>");
        }
        else LulzBot.Say(chan, helpmsg);
    }
    
    [BindCommand("atan2", "Return the angle whose tangent is the quotient of two specified numbers.", Privs.Guest)]
    public void cmd_atan2(String chan, String msg, String[] args, String from)
    {
        var helpmsg = String.Format("<b>&raquo; Usage:</b> {0}atan2 x y", LulzBot.Trigger);
        
        if (args.Length == 3)
        {
            double x = 0, y = 0;
            
            if (double.TryParse(args[1], out x) && double.TryParse(args[2], out y))
                LulzBot.Say(chan, "<b>&raquo; Result:</b> " + Math.Atan2(y, x));
            else
                LulzBot.Say(chan, "<b>&raquo; Invalid number.</b>");
        }
        else LulzBot.Say(chan, helpmsg);
    }
    
    [BindCommand("cos", "Return the cosine of the specified angle.", Privs.Guest)]
    public void cmd_cos(String chan, String msg, String[] args, String from)
    {
        var helpmsg = String.Format("<b>&raquo; Usage:</b> {0}cos angle<br/><i> * Note: Angle is in degrees.", LulzBot.Trigger);
        
        if (args.Length == 2)
        {
            double x = 0;
            
            if (double.TryParse(args[1], out x))
                LulzBot.Say(chan, "<b>&raquo; Result:</b> " + Math.Cos((x * (Math.PI / 180))));
            else
                LulzBot.Say(chan, "<b>&raquo; Invalid number.</b>");
        }
        else LulzBot.Say(chan, helpmsg);
    }
    
    [BindCommand("log", "Return the logarithm of the specified number.", Privs.Guest)]
    public void cmd_log(String chan, String msg, String[] args, String from)
    {
        var helpmsg = String.Format("<b>&raquo; Usage:</b> {0}log number <i>base</i>", LulzBot.Trigger);
        
        if (args.Length == 3)
        {
            double x = 0, nbase = 0;
            
            if (double.TryParse(args[1], out x) && double.TryParse(args[2], out nbase))
                LulzBot.Say(chan, "<b>&raquo; Result:</b> " + Math.Log(x, nbase));
            else
                LulzBot.Say(chan, "<b>&raquo; Invalid number.</b>");
        }
        else if (args.Length == 2)
        {
            double x = 0;
            
            if (double.TryParse(args[1], out x))
                LulzBot.Say(chan, "<b>&raquo; Result:</b> " + Math.Log(x));
            else
                LulzBot.Say(chan, "<b>&raquo; Invalid number.</b>");
        }
        else LulzBot.Say(chan, helpmsg);
    }
    
    [BindCommand("pow", "Return the result of the specified number raised to the specified power.", Privs.Guest)]
    public void cmd_pow(String chan, String msg, String[] args, String from)
    {
        var helpmsg = String.Format("<b>&raquo; Usage:</b> {0}pow number power", LulzBot.Trigger);
        
        if (args.Length == 3)
        {
            double x = 0, pow = 0;
            
            if (double.TryParse(args[1], out x) && double.TryParse(args[2], out pow))
                LulzBot.Say(chan, "<b>&raquo; Result:</b> " + Math.Pow(x, pow));
            else
                LulzBot.Say(chan, "<b>&raquo; Invalid number.</b>");
        }
        else LulzBot.Say(chan, helpmsg);
    }
    
    [BindCommand("sin", "Return the sine of the specified angle.", Privs.Guest)]
    public void cmd_sin(String chan, String msg, String[] args, String from)
    {
        var helpmsg = String.Format("<b>&raquo; Usage:</b> {0}sin angle<br/><i> * Note: Angle is in degrees.", LulzBot.Trigger);
        
        if (args.Length == 2)
        {
            double x = 0;
            
            if (double.TryParse(args[1], out x))
                LulzBot.Say(chan, "<b>&raquo; Result:</b> " + Math.Sin((x * (Math.PI / 180))));
            else
                LulzBot.Say(chan, "<b>&raquo; Invalid number.</b>");
        }
        else LulzBot.Say(chan, helpmsg);
    }
    
    [BindCommand("sqrt", "Return the square root of the specified number.", Privs.Guest)]
    public void cmd_sqrt(String chan, String msg, String[] args, String from)
    {
        var helpmsg = String.Format("<b>&raquo; Usage:</b> {0}sqrt number", LulzBot.Trigger);
        
        if (args.Length == 2)
        {
            double x = 0;
            
            if (double.TryParse(args[1], out x))
                LulzBot.Say(chan, "<b>&raquo; Result:</b> " + Math.Sqrt(x));
            else
                LulzBot.Say(chan, "<b>&raquo; Invalid number.</b>");
        }
        else LulzBot.Say(chan, helpmsg);
    }
    
    [BindCommand("tan", "Return the tangent of the specified angle.", Privs.Guest)]
    public void cmd_tan(String chan, String msg, String[] args, String from)
    {
        var helpmsg = String.Format("<b>&raquo; Usage:</b> {0}tan angle<br/><i> * Note: Angle is in degrees.", LulzBot.Trigger);
        
        if (args.Length == 2)
        {
            double x = 0;
            
            if (double.TryParse(args[1], out x))
                LulzBot.Say(chan, "<b>&raquo; Result:</b> " + Math.Tan((x * (Math.PI / 180))));
            else
                LulzBot.Say(chan, "<b>&raquo; Invalid number.</b>");
        }
        else LulzBot.Say(chan, helpmsg);
    }
    
    [BindCommand("pi", "Return pi.", Privs.Guest)]
    public void cmd_pi(String chan, String msg, String[] args, String from)
    {
        LulzBot.Say(chan, "<b>&raquo; PI:</b> " + Math.PI);
    }
}