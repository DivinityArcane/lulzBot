using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using lulzbot;
using lulzbot.Extensions;

[ExtensionInfo("Notes", "DivinityArcane", "1.0")]
public class Extension
{
    Dictionary<String, List<Note>> data = null;
    Dictionary<String, bool> Notified = null;

    private bool BeenNotified(String who)
    {
        if (Notified == null)
        {
            Notified = Storage.Load<Dictionary<String, bool>>("notes_n");

            if (Notified == null)
                Notified = new Dictionary<String, bool>();
        }
        
        return !(Notified.ContainsKey(who.ToLower()) && !Notified[who.ToLower()]);
    }

    private void Notify(String who, bool done = true)
    {
        if (Notified == null)
        {
            Notified = Storage.Load<Dictionary<String, bool>>("notes_n");

            if (Notified == null)
                Notified = new Dictionary<String, bool>();
        }
        
        if (!Notified.ContainsKey(who.ToLower()))
            Notified.Add(who.ToLower(), done);
        else
            Notified[who.ToLower()] = done;

        Storage.Save("notes_n", Notified);
    }

    private void Load()
    {
        data = Storage.Load<Dictionary<String, List<Note>>>("notes");

        if (data == null)
            data = new Dictionary<String, List<Note>>();
    }

    private void Save()
    {
        Storage.Save("notes", data);
    }

    private int NoteCount(String who, bool unread = false)
    {
        if (data.ContainsKey(who.ToLower()))
        {
            int count = 0;

            foreach (Note note in data[who.ToLower()])
            {
                if (unread && !note.Read)
                    count++;
                else if (!unread)
                    count++;
            }

            return count;
        }
        
        return 0;
    }
    
    [BindEvent("recv_join")]
    [BindEvent("recv_msg")]
    [BindEvent("recv_action")]
    public void check_notes(dAmnPacket packet)
    {
        if (data == null)
            Load();
        
        bool notify = false;
        String who = String.Empty;
        
		if (packet.SubCommand == "join")
        {
            who = packet.SubParameter;
            notify = data.ContainsKey(who.ToLower());
        }
		else
        {
            who = packet.Arguments["from"];
            notify = data.ContainsKey(who.ToLower());
        }

        if (notify && !BeenNotified(who))
        {
            Notify(who);
            int count = NoteCount(who, true);
            if (count > 0)
                LulzBot.Say(packet.Parameter, String.Format(":note: <b>:dev{0}:, you have {1} new note{2}!</b><br/><b>&raquo;</b> To see your notes, type {3}note list", who, count, (count == 1 ? "" : "s"), LulzBot.Trigger));
        }
    }
    
    [BindCommand("note", "Command for sending notes to other users.", Privs.Guest)]
    public void cmd_note(String chan, String msg, String[] args, String from)
    {
        if (data == null)
            Load();

        String helpmsg = String.Format("<b>&raquo; Usage:</b><br/>{0}note read/del [#]<br/>{0}note list/new/clear<br/>{0}note username message", " &middot; " + LulzBot.Trigger);
            
        if (args.Length == 1)
        {
            LulzBot.Say(chan, helpmsg);
        }
        else
        {
            String arg = args[1].ToLower(), who = from.ToLower();
            if (args.Length == 2)
            {
                switch (arg)
                {
                    case "list":
                    case "new":
                        {
                            int count = NoteCount(from, arg == "new");

                            if (count > 0)
                            {
                                String ids = String.Empty;
                                
                                for (int i = 0; i < data[who].Count; i++)
                                {
                                    Note note = data[who][i];
                                    
                                    if (arg == "new" && !note.Read)
                                        ids += String.Format(", #{0}", i + 1);
                                    else if (arg != "new")
                                        if (note.Read)
                                            ids += String.Format(", #{0}", i + 1);
                                        else
                                            ids += String.Format(", <b>#{0}</b>", i + 1);
                                }

                                LulzBot.Say(chan, String.Format("<b>&raquo; There are {0}{1} note{2} available for {3}</b>:<br/>{4}<br/><br/>{6}<i>To read a note, use {5}note read <b>#</b></i>",
                                    count, (arg == "new" ? " new" : ""), (count == 1 ? "" : "s"), from, ids.Substring(2), LulzBot.Trigger, (arg == "list" ? "<b>Bold</b> notes are unread.<br/>" : "")));
                            }
                            else
                            {
                                LulzBot.Say(chan, String.Format("<b>&raquo; There are no{0} notes for :dev{1}:</b>", (arg == "new" ? " new" : ""), from));
                            }
                        }
                        break;


                    case "clear":
                        {
                            int count = NoteCount(from, arg == "new");

                            if (count > 0)
                            {
                                data[who].Clear();
                                Save();
                                LulzBot.Say(chan, "<b>&raquo; Notes cleared!</b>");
                            }
                            else
                            {
                                LulzBot.Say(chan, String.Format("<b>&raquo; There are no notes for :dev{0}:</b>", from));
                            }
                        }
                        break;
                    
                    
                    default:
                        LulzBot.Say(chan, helpmsg);
                        break;
                }
            }
            else
            {
                if (arg == "read")
                {
                    if (data.ContainsKey(who))
                    {
                        int id = 0;
                        bool parsed = Int32.TryParse(args[2], out id);
                        id = id - 1;

                        if (parsed && id >= 0 && id < data[who].Count)
                        {
                            Note note = data[who][id];
                            
                            if (!note.Read)
                            {
                                note.Read = true;
                                data[who][id] = note;
                                Save();
                            }

                            LulzBot.Say(chan, String.Format("<b>&raquo; From: :dev{0}: on <i>{1}</i></b><br/><br/>{2}", note.Sender, Tools.strftime("%c", note.Timestamp), note.Body));
                        }
                        else
                        {
                            LulzBot.Say(chan, String.Format("<b>&raquo; There is no such note for :dev{0}:</b>", from));
                        }
                    }
                    else
                    {
                        LulzBot.Say(chan, String.Format("<b>&raquo; There are no notes for :dev{0}:</b>", from));
                    }
                }
                else if (arg == "del")
                {
                    if (data.ContainsKey(who))
                    {
                        int id = 0;
                        bool parsed = Int32.TryParse(args[2], out id);
                        id = id - 1;

                        if (parsed && id >= 0 && id < data[who].Count)
                        {
                            data[who].RemoveAt(id);

                            LulzBot.Say(chan, "<b>&raquo; Note deleted!");
                        }
                        else
                        {
                            LulzBot.Say(chan, String.Format("<b>&raquo; There is no such note for :dev{0}:</b>", from));
                        }
                    }
                    else
                    {
                        LulzBot.Say(chan, String.Format("<b>&raquo; There are no notes for :dev{0}:</b>", from));
                    }
                }
                else
                {
                    String target = args[1].ToLower();
                    String body = msg.Substring(2 + args[0].Length + args[1].Length);
                    
                    Note note = new Note() {
                        Timestamp = Tools.Timestamp(),
                        Read = false,
                        Sender = from,
                        Body = body};

                    if (!data.ContainsKey(target))
                        data.Add(target, new List<Note>());

                    data[target].Add(note);
                    Save();
                    Notify(target, false);
                    
                    LulzBot.Say(chan, "<b>&raquo; Note sent!</b>");
                }
            }
        }
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 0)]
public struct Note
{
    public int Timestamp;
    public bool Read;
    public String Sender, Body;
} 
