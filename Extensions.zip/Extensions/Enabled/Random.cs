using System;
using lulzbot;
using lulzbot.Extensions;

[ExtensionInfo("Random", "DivinityArcane", "1.0")]
public class Extension
{
    Random rand = new Random();

    [BindCommand("random", "Generates a random number, in a given range [if specified]", Privs.Guest, "[trig]random<br/>[trig]random max<br/>[trig]random min max")]
    public void cmd_random(String chan, String msg, String[] args, String from)
    {
        String helpmsg = String.Format("<b>&raquo; Usage:</b> {0}random{0}random max{0}random min max<br/><br/><i><sub>* min and max must be valid integers, and max must be higher than min.</sub></i>", "<br/><b> &middot; </b> " + LulzBot.Trigger);
        String fmt = "<b>&raquo; Your random number is:</b> {0}";

        if (args.Length == 1)
            LulzBot.Say(chan, String.Format(fmt, rand.Next()));
        else
        {
            int min = 0, max = 0;
            
            if (args.Length == 2)
            {
                if (args[1] == "?" || args[1] == "-?" || args[1] == "help")
                {
                    LulzBot.Say(chan, helpmsg);
                    return;
                }
                    
                if (!int.TryParse(args[1], out max) || max < 0)
                {
                    LulzBot.Say(chan, helpmsg);
                    return;
                }

                LulzBot.Say(chan, String.Format(fmt, rand.Next(max)));
            }
            else if (args.Length == 3)
            {
                if (!int.TryParse(args[1], out min) || !int.TryParse(args[2], out max) || max <= min || max < 0)
                {
                    LulzBot.Say(chan, helpmsg);
                    return;
                }
                    
                LulzBot.Say(chan, String.Format(fmt, rand.Next(min, max)));
            }
            else LulzBot.Say(chan, helpmsg);
        }
    }
    
    [BindCommand("rdeviant", "Random deviant command!", Privs.Guest, "[trig]rdeviant")]
    public void cmd_rdeviant(String chan, String msg, String[] args, String from)
    {
        String page = Tools.GrabPage(@"http://www.deviantart.com/random/deviant");

        String name;
        int posA, posB;

        if ((posB = page.IndexOf(@" on deviantART</title>")) == -1)
        {
            LulzBot.Say(chan, "<b>&raquo; Unable to retreive a random deviant at this time.</b>");
            return;
        }

        if ((posA = page.IndexOf(@"<title>")) != -1)
        {
            name = page.Substring(posA + 7, posB - (posA + 7));
            LulzBot.Say(chan, "<b>&raquo; Your random deviant is:</b> :dev" + name + ":");
        }
        else LulzBot.Say(chan, "<b>&raquo; Unable to retreive a random deviant at this time.</b>");
    }
    
    [BindCommand("rdeviation", "Random deviation command!", Privs.Guest, "[trig]rdeviation")]
    public void cmd_rdeviation(String chan, String msg, String[] args, String from)
    {
        String page = Tools.GrabPage(@"http://www.deviantart.com/random/deviation");

        String id;
        int posA, posB;

        if ((posA = page.IndexOf("value=\":thumb")) != -1)
        {
            posB = page.Substring(posA + 13).IndexOf(":");
            id = page.Substring(posA + 13, posB);
            LulzBot.Say(chan, "<b>&raquo; Your random deviation is:</b> :thumb" + id + ":");
        }
        else LulzBot.Say(chan, "<b>&raquo; Unable to retreive a random deviation at this time.</b>");
    }
    
    [BindCommand("rgroup", "Random group command!", Privs.Guest, "[trig]rgroup")]
    public void cmd_rgroup(String chan, String msg, String[] args, String from)
    {
        String page = Tools.GrabPage(@"http://www.deviantart.com/random/group");

        String name;
        int posA, posB;

        if ((posB = page.IndexOf(@" on deviantART</title>")) == -1)
        {
            LulzBot.Say(chan, "<b>&raquo; Unable to retreive a random group at this time.</b>");
            return;
        }

        if ((posA = page.IndexOf(@"<title>#")) != -1)
        {
            name = page.Substring(posA + 8, posB - (posA + 8));
            LulzBot.Say(chan, "<b>&raquo; Your random group is:</b> :dev" + name + ":");
        }
        else LulzBot.Say(chan, "<b>&raquo; Unable to retreive a random group at this time.</b>");
    }
}
