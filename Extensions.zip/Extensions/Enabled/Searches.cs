using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using lulzbot;
using lulzbot.Extensions;

[ExtensionInfo("Searches", "DivinityArcane", "1.0")]
public class Extension
{
    public JObject GrabJson(String type, String query, String accept = "text/plain", String encoding="ASCII")
    {
        try
        {
            String url, body;
            bool unescape = false;
            query = Uri.EscapeDataString(query);
            switch (type)
            {
                case "google":
                    url = @"http://ajax.googleapis.com/ajax/services/search/web?v=1.0&rsz=3&safe=active&q=" + query;
                    encoding = "UTF-8";
                    accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8;utf-8";
                    break;

                case "gcalc":
                    url = @"http://www.google.com/ig/calculator?hl=en&q=" + query;
                    unescape = true;
                    break;

                case "wikipedia":
                    url = @"http://en.wikipedia.org/w/api.php?action=query&list=search&format=json&srwhat=text&srsearch=" + query;
                    encoding = "UTF-8";
                    accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8;utf-8";
                    break;

                case "botdom":
                    url = @"http://botdom.com/w/api.php?action=query&list=search&format=json&srwhat=text&srsearch=" + query;
                    break;

                case "docs":
                    url = @"http://botdom.com/d/api.php?action=query&list=search&format=json&srwhat=text&srsearch=" + query;
                    break;

                case "thumbinfo":
                    url = @"http://backend.deviantart.com/oembed?url=" + query;
                    break;

                case "weather":
                    url = @"http://free.worldweatheronline.com/feed/weather.ashx?format=json&num_of_days=1&key=5ea0d0bf10080502122111&q=" + query;
                    break;

                case "ud":
                    url = @"http://api.urbandictionary.com/v0/define?term=" + query;
                    encoding = "UTF-8";
                    accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8;utf-8";
                    break;

                case "define":
                    url = @"http://cleandictionary.com/s/" + query;
                    break;

                case "spell":
                    url = @"http://cleandictionary.com/c/" + query;
                    break;

                case "tweet":
                    url = @"http://api.twitter.com/1/statuses/show.json?id=" + query;
                    encoding = "UTF-8";
                    accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8;utf-8";
                    break;
                    
                case "youtube":
                    url = @"http://gdata.youtube.com/feeds/api/videos?max-results=3&v=2&alt=jsonc&q=" + query;
                    encoding = "UTF-8";
                    accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8;utf-8";
                    break;
                    
                case "damnit":
                    url = @"http://damnit.apphb.com/quotes.aspx";
                    break;
                    
                case "isohunt":
                    url = @"http://isohunt.com/js/json.php?&start=0&rows=5&sort=seeds&ihq=" + query;
                    break;
                
                default:
                    return null;
            }
            
            body = Tools.GrabPage(url, accept:accept, encoding:encoding);
            
            if (encoding == "UTF-8")
            {
                body = Tools.HtmlEncode(body);
            }
            
            if (unescape)
                body = Regex.Unescape(body);
            return (body == null ? null : JObject.Parse(body));
        }
        catch { return null; }
    }

    public JArray GrabJsonArray(String type, String query)
    {
        try
        {
            String url, body, accept = "text/plain";
            bool unescape = false;
            query = Uri.EscapeDataString(query);
            switch (type)
            {
                case "twitter":
                    url = @"http://api.twitter.com/1/statuses/user_timeline.json?include_entities=false&include_rts=false&count=3&screen_name=" + query;
                    break;
                
                default:
                    return null;
            }

            body = Tools.GrabPage(url, accept:accept);
            if (unescape)
                body = Regex.Unescape(body);
            return (body == null ? null : JArray.Parse(body));
        }
        catch { return null; }
    }

    //[StructLayout(LayoutKind.Sequential, Pack = 0)]
    public struct SearchResult
    {
        public string Url;
        public string Title;
        public string Content;
    }

    public struct ThumbInfo
    {
        public string Title;
        public string Category;
        public string Author;
    }

    public struct Definition
    {
        public string Content;
        public string WordType;
    }

    public struct Tweet
    {
        public string Author;
        public string Date;
        public string Content;
        public string ID;
    }
    
    public struct YTVid
    {
        public string ID;
        public string Uploaded;
        public string Uploader;
        public string Category;
        public string Title;
        public string Description;
    }
    
    public struct dAmnQuote
    {
        public string ID;
        public string Link;
        public string Author;
        public string Date;
        public string Content;
    }
    
    public struct Torrent
    {
        public string Title;
        public string Link;
        public string Size;
        public string Files;
        public string Seeds;
        public string Leeches;
        public string Downloads;
        public string Date;
    }

    private static Regex _define_braces = new Regex(@"\{\{[^}]*\}\}", RegexOptions.Compiled);
    private static Regex _define_brackets = new Regex(@"\[\[([^]]*)\]\]", RegexOptions.Compiled);
    
    [BindCommand("google", "Google search.", Privs.Guest)]
    public void cmd_google(String chan, String msg, String[] args, String from)
    {
        if (args.Length >= 2)
        {
            String query = msg.Substring(7);
            JObject res = GrabJson("google", query);

            if (res == null)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }
            
            List<SearchResult> results = new List<SearchResult>();
            var res_query =
                from result in res["responseData"]["results"].Children()
                select new SearchResult() { 
                    Url     = result.Value<string>("url").ToString(),
                    Content = result.Value<string>("content").ToString(),
                    Title   = result.Value<string>("title").ToString()
                };

            foreach (var nres in res_query) results.Add(nres);

            if (results.Count <= 0)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }

            String output = String.Format("<b>Google's top {0} result{1}:</b>", results.Count, results.Count == 1 ? "" : "s");

            foreach (SearchResult result in results) {
                output += String.Format("<br/><br/> &raquo; <a href=\"{0}\"><b>{1}</b></a><br/>&nbsp;&nbsp;&middot;<i>{2}</i>",
                    result.Url, result.Title, result.Content);
            }

            output += String.Format("<br/><br/><sub><i>Click <a href=\"https://www.google.com/search?q={0}\">here</a> to view more results.</i></sub>", query);
            
            LulzBot.Say(chan, output);
        }
        else
        {
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}google query", LulzBot.Trigger));
        }
    }
    
    [BindCommand("gcalc", "Google calculator.", Privs.Guest)]
    public void cmd_gcalc(String chan, String msg, String[] args, String from)
    {
        if (args.Length >= 2)
        {
            String query = msg.Substring(6);
            JObject res = GrabJson("gcalc", query);

            if (res == null)
            {
                LulzBot.Say(chan, "<b>&raquo; Unable to process expression!</b>");
                return;
            }

            String exp = res.Value<String>("lhs");
            String val = res.Value<String>("rhs");

            if (val == null || val.Length <= 0)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }
            
            LulzBot.Say(chan, String.Format("<b>&raquo; Your expression:</b> {0}<br/><b>&raquo; Result:</b> {1}", exp, val));
        }
        else
        {
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}gcalc expression", LulzBot.Trigger));
        }
    }
    
    [BindCommand("wikipedia", "Wikipedia search.", Privs.Guest)]
    public void cmd_wikipedia(String chan, String msg, String[] args, String from)
    {
        if (args.Length >= 2)
        {
            String query = msg.Substring(10);
            JObject res = GrabJson("wikipedia", query);

            if (res == null)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }
            
            List<SearchResult> results = new List<SearchResult>();
            var res_query =
                from result in res["query"]["search"].Children()
                select new SearchResult() { 
                    Title   = result.Value<String>("title").ToString()
                };

            foreach (var nres in res_query)
            {
                results.Add(nres);
                if (results.Count >= 10) break;
            }

            if (results.Count <= 0)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }

            String output = String.Format("<b>Wikipedia's top {0} result{1}:</b><br/>", results.Count, results.Count == 1 ? "" : "s");

            foreach (SearchResult result in results) {
                output += String.Format("<br/> &raquo; <a href=\"http://www.wikipedia.com/wiki/{0}\"><b>{0}</b></a>", result.Title);
            }

            output += String.Format("<br/><br/><sub><i>Click <a href=\"http://wikipedia.com/w/index.php?title=Special:Search&search={0}&fulltext=Search&profile=advanced&redirs=0\">here</a> to view more results.</i></sub>", query);
            
            LulzBot.Say(chan, output);
        }
        else
        {
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}wikipedia query", LulzBot.Trigger));
        }
    }
    
    [BindCommand("botdom", "Botdom wiki search.", Privs.Guest)]
    public void cmd_botdom(String chan, String msg, String[] args, String from)
    {
        if (args.Length >= 2)
        {
            String query = msg.Substring(7);
            JObject res = GrabJson("botdom", query);

            if (res == null)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }
            
            List<SearchResult> results = new List<SearchResult>();
            var res_query =
                from result in res["query"]["search"].Children()
                select new SearchResult() { 
                    Title   = result.Value<String>("title").ToString()
                };

            foreach (var nres in res_query)
            {
                results.Add(nres);
                if (results.Count >= 10) break;
            }

            if (results.Count <= 0)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }

            String output = String.Format("<b>Botdom wiki's top {0} result{1}:</b><br/>", results.Count, results.Count == 1 ? "" : "s");

            foreach (SearchResult result in results) {
                output += String.Format("<br/> &raquo; <a href=\"http://www.botdom.com/wiki/{0}\"><b>{0}</b></a>", result.Title);
            }

            output += String.Format("<br/><br/><sub><i>Click <a href=\"http://botdom.com/w/index.php?title=Special:Search&search={0}&fulltext=Search&profile=advanced&redirs=0\">here</a> to view more results.</i></sub>", query);
            
            LulzBot.Say(chan, output);
        }
        else
        {
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}botdom query", LulzBot.Trigger));
        }
    }
    
    [BindCommand("docs", "Botdom docs search.", Privs.Guest)]
    public void cmd_docs(String chan, String msg, String[] args, String from)
    {
        if (args.Length >= 2)
        {
            String query = msg.Substring(5);
            JObject res = GrabJson("docs", query);
            
            if (res == null)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }
            
            List<SearchResult> results = new List<SearchResult>();
            var res_query =
                from result in res["query"]["search"].Children()
                select new SearchResult() { 
                    Title   = result.Value<String>("title").ToString()
                };

            foreach (var nres in res_query)
            {
                results.Add(nres);
                if (results.Count >= 10) break;
            }

            if (results.Count <= 0)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }

            String output = String.Format("<b>Botdom documentation's top {0} result{1}:</b><br/>", results.Count, results.Count == 1 ? "" : "s");

            foreach (SearchResult result in results) {
                output += String.Format("<br/> &raquo; <a href=\"http://www.botdom.com/docs/{0}\"><b>{0}</b></a>", result.Title);
            }

            output += String.Format("<br/><br/><sub><i>Click <a href=\"http://botdom.com/d/index.php?title=Special:Search&search={0}&fulltext=Search&profile=advanced&redirs=0\">here</a> to view more results.</i></sub>", query);
            
            LulzBot.Say(chan, output);
        }
        else
        {
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}docs query", LulzBot.Trigger));
        }
    }
    
    [BindCommand("thumbinfo", "dA thumb info search.", Privs.Guest)]
    public void cmd_thumbinfo(String chan, String msg, String[] args, String from)
    {
        if (args.Length >= 2)
        {
            String query = msg.Substring(10);
            JObject res = GrabJson("thumbinfo", query);

            if (res == null)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }
            
            ThumbInfo result = new ThumbInfo()
            {
                Title = res.Value<String>("title").ToString(),
                Category = res.Value<String>("category").ToString(),
                Author = res.Value<String>("author_name").ToString()
            };

            String output = String.Format("<b>Thumb information for {0}:</b><br/>", query);
            output += String.Format("<br/> &raquo; Name: <b><code>{0}</code></b> by :dev{1}:", result.Title, result.Author);
            output += String.Format("<br/> &raquo; Category: {0}", result.Category);
            
            LulzBot.Say(chan, output);
        }
        else
        {
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}thumbinfo query", LulzBot.Trigger));
        }
    }
    
    [BindCommand("urbandict", "Urban dictionary search.", Privs.Guest)]
    public void cmd_urbandict(String chan, String msg, String[] args, String from)
    {
        if (args.Length >= 2)
        {
            String query = msg.Substring(10);
            JObject res = GrabJson("ud", query);

            if (res == null)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }
            
            List<SearchResult> results = new List<SearchResult>();
            var res_query =
                from result in res["list"].Children()
                select new SearchResult() {
                    Title = result.Value<String>("word").ToString(),
                    Url = result.Value<String>("permalink").ToString(),
                    Content = result.Value<String>("definition").ToString()
                };

            foreach (var nres in res_query)
            {
                results.Add(nres);
                if (results.Count >= 3) break;
            }

            if (results.Count <= 0)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }

            String output = String.Format("<b>Urban Dictionary's top {0} result{1} for {2}:</b><br/>", results.Count, results.Count == 1 ? "" : "s", query);

            foreach (SearchResult result in results)
            {
                String content = result.Content;
                if (content.Length > 47)
                    content = content.Substring(0, 47) + "...";
                output += String.Format("<br/><b> &middot; <a href=\"{0}\">{1}</a></b><br/> &middot; {2}<br/>", result.Url, result.Title, content);
            }

            output += String.Format("<br/><b> &raquo; <a href=\"http://www.urbandictionary.com/define.php?term={0}\">Click here to view more results.</a></b>", query);
            
            LulzBot.Say(chan, output);
        }
        else
        {
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}urbandict query", LulzBot.Trigger));
        }
    }
    
    //[BindCommand("define", "Dictionary search.", Privs.Guest)]
    public void cmd_define(String chan, String msg, String[] args, String from)
    {
        if (args.Length >= 2)
        {
            String query = msg.Substring(7);
            JObject res = GrabJson("define", query);

            if (res == null)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }
            
            List<Definition> results = new List<Definition>();
            var res_query =
                from result in res["result"][0]["defs"].Children()
                select new Definition() {
                    Content = result.ToString()
                };

            foreach (var nres in res_query)
            {
                results.Add(nres);
                if (results.Count >= 3) break;
            }

            if (results.Count <= 0)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }

            String output = String.Format("<b>Found {0} definition{1} for {2}:</b><br/>", results.Count, results.Count == 1 ? "" : "s", query);

            foreach (Definition result in results)
            {
                String content = result.Content;
                content = _define_braces.Replace(content, "");
                content = _define_brackets.Replace(content, "<i>$1</i>");
                output += String.Format("<br/><b> &middot; {0}<br/>", content);
            }
            
            LulzBot.Say(chan, output);
        }
        else
        {
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}define word", LulzBot.Trigger));
        }
    }
    
    //[BindCommand("spell", "Spell check search.", Privs.Guest)]
    public void cmd_spell(String chan, String msg, String[] args, String from)
    {
        if (args.Length >= 2)
        {
            String query = args[1];
            JObject res = GrabJson("spell", query);

            if (res == null)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }
            
            List<String> results = new List<String>();
            var res_query =
                from result in res["result"].Children()
                select result.ToString();

            foreach (var nres in res_query)
            {
                results.Add(nres);
            }

            if (results.Count == 0)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }
            else if (results.Count == 1 && results[0] == query.ToLower())
            {
                LulzBot.Say(chan, String.Format("<b>&raquo; It looks like <i>{0}</i> is spelled correctly.</b>", query));
                return;
            }

            String output = String.Format("<b>&raquo; Found {0} different spelling{1} for {2}:</b> {3}", results.Count, results.Count == 1 ? "" : "s", query, String.Join(", ", results));
            
            LulzBot.Say(chan, output);
        }
        else
        {
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}spell word", LulzBot.Trigger));
        }
    }
    
    [BindCommand("tweets", "Twitter tweet search.", Privs.Guest)]
    public void cmd_tweets(String chan, String msg, String[] args, String from)
    {
        if (args.Length >= 2)
        {
            String query = args[1];
            JArray res = GrabJsonArray("twitter", query);

            if (res == null)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }
            
            List<Tweet> results = new List<Tweet>();
            var res_query =
                from result in res
                select new Tweet
                {
                    Author = result["user"]["screen_name"].ToString(),
                    Date = result["created_at"].ToString(),
                    ID = result["id"].ToString(),
                    Content = result["text"].ToString()
                };

            foreach (var nres in res_query)
            {
                results.Add(nres);
            }

            if (results.Count == 0)
            {
                LulzBot.Say(chan, "<b>&raquo; No tweets were found!</b>");
                return;
            }
            
            String output = String.Format("<b>&raquo; Top {0} tweet{1} for {2}:</b><br/>", results.Count, results.Count == 1 ? "" : "s", query);

            foreach (Tweet result in results)
            {
                output += String.Format("<br/><b>&raquo; <a href=\"https://twitter.com/{1}/status/{0}\">By {1} on {2}</a></b>:<br/> &middot; {3}<br/>", result.ID, result.Author, result.Date, result.Content);
            }
            
            LulzBot.Say(chan, output);
        }
        else
        {
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}tweets username", LulzBot.Trigger));
        }
    }
    
    [BindCommand("tweet", "Twitter tweet search.", Privs.Guest)]
    public void cmd_tweet(String chan, String msg, String[] args, String from)
    {
        if (args.Length >= 2)
        {
            String query = args[1];
            JObject res = GrabJson("tweet", query);

            if (res == null)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }
            
            Tweet result = new Tweet
                {
                    Author = res["user"]["screen_name"].ToString(),
                    Date = res["created_at"].ToString(),
                    ID = res["id"].ToString(),
                    Content = res["text"].ToString()
                };

            String output = "<b>&raquo; Tweet information:</b>";
            output += String.Format("<br/><b>&raquo; <a href=\"https://twitter.com/{1}/status/{0}\">By {1} on {2}</a></b>:<br/> &middot; {3}<br/>", result.ID, result.Author, result.Date, result.Content);
            
            LulzBot.Say(chan, output);
        }
        else
        {
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}tweet id", LulzBot.Trigger));
        }
    }
    
    [BindCommand("weather", "Weather search.", Privs.Guest)]
    public void cmd_weather(String chan, String msg, String[] args, String from)
    {
        if (args.Length >= 2)
        {
            String query = msg.Substring(8);
            JObject res = GrabJson("weather", query);

            if (res == null || res["data"].Count(x=>true) == 1)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }

            String output = String.Format("<b>&raquo; Weather information for [{0}] {1}:</b><br/>", res["data"]["request"][0]["type"], res["data"]["request"][0]["query"]);

            output += "<br/><b> &middot; Cloud cover:</b> " + res["data"]["current_condition"][0]["cloudcover"] + "%";
            output += "<br/><b> &middot; Humidity:</b> " + res["data"]["current_condition"][0]["humidity"] + "%";
            output += "<br/><b> &middot; Precipitation (mm):</b> " + res["data"]["current_condition"][0]["precipMM"] + "mm";
            output += "<br/><b> &middot; Air Pressure:</b> " + res["data"]["current_condition"][0]["pressure"];
            output += "<br/><b> &middot; Temperature:</b> " + res["data"]["current_condition"][0]["temp_F"] + "&deg;F / " + res["data"]["current_condition"][0]["temp_C"] + "&deg;C";
            output += "<br/><b> &middot; Wind:</b> " + res["data"]["current_condition"][0]["windspeedMiles"] + "MPH " + res["data"]["current_condition"][0]["winddir16Point"];
            output += "<br/><b> &middot; Weather:</b> " + res["data"]["current_condition"][0]["weatherDesc"][0]["value"];

            LulzBot.Say(chan, output);
        }
        else
        {
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}weather city/zipcode", LulzBot.Trigger));
        }
    }

    Regex username_regex = new Regex(@"<title>([^\s]+) on deviantART</title>", RegexOptions.Compiled);
    Regex body_regex = new Regex(@"(<span>Formerly <strong>([^<]+)</strong></span>|<strong class=""f"">([^<]+)</strong>|<strong>([^\s]+) </strong> ?([^<\s]+)(\s([^<\s]+))?|<d(t|d) class=""f h"">([^<]+)</d(t|d)>)", RegexOptions.Compiled);
    Regex line_match = new Regex(@"<strong>([^\s]+) </strong> ?(([^<\s]+)(\s([^<\s]+))?)", RegexOptions.Compiled);
    
    [BindCommand("devinfo", "Deviant information search.", Privs.Guest)]
    public void cmd_devinfo(String chan, String msg, String[] args, String from)
    {
        if (args.Length >= 2)
        {
            String query = args[1];
            String page = Tools.GrabPage(String.Format(@"http://{0}.deviantart.com/", query));
            Match un_match = null;//, matches;

            if (page != null)
                un_match = username_regex.Match(page);

            if (page == null || !un_match.Success)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }

            String deviant = un_match.Groups[1].Value;

            String output = String.Format("<b>&raquo; :icon{0}: Information on deviant :dev{0}::</b><br/>", deviant);

            List<String> got = new List<String>();

            foreach (Match match in body_regex.Matches(page))
            {
                String tag = match.Groups[1].Value.Substring(0, match.Groups[1].Value.IndexOf(">") + 1);
                switch (tag)
                {
                    case "<span>":
                        output += String.Format("<br/><b>&raquo;</b> :dev{0}: was previously known as <b>{1}</b>", deviant, match.Groups[2].Value);
                        break;

                    case "<strong class=\"f\">":
                        output += "<br/><b>&raquo;</b> " + match.Groups[3].Value;
                        break;

                    case "<strong>":
                        Match info = line_match.Match(match.Groups[1].Value);

                        if (info.Success && !got.Contains(info.Groups[2].Value))
                        {
                            got.Add(info.Groups[2].Value);
                            output += String.Format("<br/><b>&raquo;</b> They have <b>{0}</b> {1}", info.Groups[1].Value, info.Groups[2].Value);
                        }
                        break;

                    case "<dd class=\"f h\">":
                        output += "<br/><b>&raquo;</b> " + match.Groups[9].Value;
                        break;
                    
                    default: Console.WriteLine("'{0}'", tag); break;
                }
            }

            LulzBot.Say(chan, output);
        }
        else
        {
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}devinfo username", LulzBot.Trigger));
        }
    }
    
    Regex commits_match_regex = new Regex("<tr><td><span class='age-hours'>([^<]*)</span></td><td><a href='([^<]*)'>([^<]*)</a>.*?</td><td>([^<]*)</td><td>[^<]*</td><td>([^<]*)</td></tr>", RegexOptions.Compiled);
    Regex commits_replace_regex = new Regex("<tr><td><span class='age-hours'>([^<]*)</span></td><td><a href='([^<]*)'>([^<]*)</a>.*?</td><td>([^<]*)</td><td>[^<]*</td><td>([^<]*)</td></tr>", RegexOptions.Compiled);
    
    [BindCommand("kernel", "Kernel.org information search.", Privs.Guest)]
    public void cmd_kernel(String chan, String msg, String[] args, String from)
    {
        String page = Tools.GrabPage(@"http://git.kernel.org/?p=linux/kernel/git/torvalds/linux.git;a=summary");

        if (page.Length <= 0)
        {
            LulzBot.Say(chan, "<b>&raquo; Unable to grab information at this time.</b>");
            return;
        }

        String output = "<b>&raquo; Latest commits to the <a href=\"http://git.kernel.org/?p=linux/kernel/git/torvalds/linux.git;a=summary\">Linux kernel</a>:</b><br/>";
        int max_displayed = 5;

        foreach (Match link in commits_match_regex.Matches(page))
        {
            output += commits_replace_regex.Replace(link.Value, "<br/><b> &middot; $1 ago by <a href=\"http://git.kernel.org/cgit/linux/kernel/git/torvalds/linux.git/log/?qt=author&q=$4\">$4</a>:</b><br/> &middot; <a href=\"http://git.kernel.org/$2\">$3</a> [<b>$5</b>]<br/>");
            max_displayed--;
            if (max_displayed <= 0) break;
        }

        output += "<br/><b>&raquo; <a href=\"http://git.kernel.org/?p=linux/kernel/git/torvalds/linux.git;a=shortlog\">View more</a></b>";

        LulzBot.Say(chan, output);
    }
    
    [BindCommand("youtube", "YouTube video search.", Privs.Guest)]
    public void cmd_youtube(String chan, String msg, String[] args, String from)
    {
        if (args.Length >= 2)
        {
            String query = msg.Substring(8);
            JObject res = GrabJson("youtube", query);

            if (res == null || (int)res["data"]["totalItems"] == 0)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }
            
            List<YTVid> results = new List<YTVid>();
            
            foreach (var vid in res["data"]["items"])
            {
                results.Add(new YTVid()
                    {
                        ID          = vid["id"].ToString(),
                        Uploaded    = vid["uploaded"].ToString(),
                        Uploader    = vid["uploader"].ToString(),
                        Category    = vid["category"].ToString(),
                        Title       = vid["title"].ToString(),
                        Description = vid["description"].ToString()
                    });
            }

            String output = String.Format("<b>&raquo; Top {0} video{1} matching your search:</b><br/>", results.Count, results.Count == 1 ? "" : "s");

            foreach (var vid in results)
            {
                output += String.Format("<br/><b>&raquo; <a href=\"http://www.youtube.com/watch?v={0}\">{1}</a></b> - Uploaded {2} ago by <b><a href=\"http://www.youtube.com/user/{3}\">{3}</a></b><br/>", vid.ID, vid.Title, Tools.FormatTime((int)(DateTime.UtcNow - DateTime.Parse(vid.Uploaded)).TotalSeconds), vid.Uploader);
                output += String.Format(" <b>&middot; Category:</b> {0}<br/> <b>&middot; Description:</b> {1}<br/>", vid.Category, vid.Description);
            }

            LulzBot.Say(chan, output);
        }
        else
        {
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}youtube search_query", LulzBot.Trigger));
        }
    }
    
    Regex img2emote = new Regex("<img src=\"[^\"]+\" width=\"[^\"]+\" height=\"[^\"]+\" alt=\"([^\"]+)\" title=\"[^\"]+\"/>", RegexOptions.Compiled);
    Regex img2avatar = new Regex("<a target=\"_self\" href=\"[^\"]+\"><img class=\"avatar\" src=\"[^\"]+\" alt=\"([^\"]+)\" title=\"[^\"]+\" /></a>", RegexOptions.Compiled);
    
    [BindCommand("damnit", "dAmnIT quotes", Privs.Guest)]
    public void cmd_damnit(String chan, String msg, String[] args, String from)
    {
        JObject res = GrabJson("damnit", "");

        if (res == null || res.Value<string>("response").ToString() != "OK")
        {
            LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
            return;
        }
        
        List<dAmnQuote> results = new List<dAmnQuote>();
        
        for (int i = 0; i < 30; i++)
        {
            var quote = res["quotes"][""+i];
            if (quote == null) continue;
            results.Add(new dAmnQuote()
                {
                    ID              = quote["id"].ToString(),
                    Link            = quote["link"].ToString(),
                    Author          = quote["author"].ToString(),
                    Date            = quote["date"].ToString(),
                    Content         = quote["content"].ToString(),
                });
        }
        
        if (results.Count == 0)
        {
            LulzBot.Say(chan, "<b>&raquo; No quotes were returned.</b>");
            return;
        }

        String output = "<b>&raquo; Random quote from the most recent 30:</b><br/>";
        
        var q = results[new Random().Next(0, results.Count)];
        
        while (q.Link == null) q = results[new Random().Next(0, results.Count)];
        
        output += String.Format("<br/> <b>&middot; <a href=\"{0}\">Quote #{1}</a> - Submitted by :dev{2}: on {3}</b><br/><br/>{4}", q.Link, q.ID, q.Author, q.Date, img2emote.Replace(img2avatar.Replace(Uri.UnescapeDataString(q.Content), "$1"), "$1"));

        LulzBot.Say(chan, output);
    }
    
    [BindCommand("isohunt", "ISOHunt torrent search.", Privs.Members)]
    public void cmd_isohunt(String chan, String msg, String[] args, String from)
    {
        if (args.Length >= 2)
        {
            String query = msg.Substring(7);
            JObject res = GrabJson("isohunt", query);

            if (res == null || (int)res["total_results"] == 0)
            {
                LulzBot.Say(chan, "<b>&raquo; No results were found!</b>");
                return;
            }
            
            List<Torrent> results = new List<Torrent>();
            
            foreach (var torrent in res["items"]["list"])
            {
                results.Add(new Torrent()
                    {
                        Title       = torrent["title"].ToString(),
                        Link        = torrent["link"].ToString(),
                        Size        = torrent["size"].ToString(),
                        Files       = torrent["files"].ToString(),
                        Seeds       = torrent["Seeds"].ToString(),
                        Leeches     = torrent["leechers"].ToString(),
                        Downloads   = torrent["downloads"].ToString(),
                        Date        = torrent["pubDate"].ToString()
                    });
            }

            String output = String.Format("<b>&raquo; Top {0} torrent{1} matching your search:</b><br/>", results.Count, results.Count == 1 ? "" : "s");

            foreach (var torrent in results)
            {
                output += String.Format("<br/><b>&raquo;</b> <a href=\"{0}\">{1}</a> - {2} / {3} files - {4}S / {5}L - {6} DLs since {7}<br/>", torrent.Link, torrent.Title, torrent.Size, torrent.Files, torrent.Seeds, torrent.Leeches, torrent.Downloads, torrent.Date);
            }

            LulzBot.Say(chan, output);
        }
        else
        {
            LulzBot.Say(chan, String.Format("<b>&raquo; Usage:</b> {0}isohunt search_query", LulzBot.Trigger));
        }
    }
}
