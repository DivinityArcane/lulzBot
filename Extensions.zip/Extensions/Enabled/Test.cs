using System;
using lulzbot;
using lulzbot.Extensions;

// Name, Author, Version.
[ExtensionInfo("Test", "DivinityArcane", "1.0")]
public class Extension
{
    // Can bind multiple events.
    // Event, Description
    //[BindEvent("recv_join", "Test event!")]
    //[BindEvent("recv_part", "Test event!")]
    public void SomeAwesomeEventHandler(dAmnPacket packet)
    {
        if (packet.Parameter != "chat:DeviousDevelopment")
            return;
            
		if (packet.SubCommand == "join")
        {
			LulzBot.Say(packet.Parameter, "Welcome, :dev" + packet.SubParameter + ":!");
        }
		else if (packet.SubCommand == "part")
        {
			LulzBot.Say(packet.Parameter, "Aw :( I'll miss :dev" + packet.SubParameter + ":");
        }
    }
    
    // As well as multiple commands.
    // Command, Description, Minimum privs
    [BindCommand("test", "Test command!", Privs.Guest, "[trig]test")]
    //[BindCommand("test2", "Another test command!", Privs.Guest, "[trig]test2")]
    public void TotallyAwesomeCommand(String chan, String msg, String[] args, String from)
    {
        LulzBot.Say(chan, "Hello there, " + from + "!");
    }
    
    [BindCommand("tab", "Test command!", Privs.Guest, "[trig]tab <i>username</i>")]
    public void cmd_tab(String chan, String msg, String[] args, String from)
    {
        if (args.Length == 1)
            LulzBot.Say(chan, String.Format("Hello, {0}!", from));
        else
            LulzBot.Say(chan, String.Format("Hello, {0}!", args[1]));
    }
}
