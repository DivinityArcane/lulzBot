using System;
using lulzbot;
using lulzbot.Extensions;
using System.Collections.Generic;
using System.Text.RegularExpressions;

[ExtensionInfo("ThumbShare", "DivinityArcane", "1.0")]
public class Extension
{
    Random rand = new Random();
	
	Regex gallery_re = new Regex(@"<link>\r?\n?.*-(\d+)\r?\n?</link>", RegexOptions.Compiled);

    [BindCommand("art", "Grabs a random set of thumbs from the specified deviant's gallery", Privs.Members)]
    public void cmd_art(String chan, String msg, String[] args, String from)
    {
        String helpmsg = String.Format("<b>&raquo; Usage:</b> {0}art <i>username</i>{0}art <i>username #count</i><br/><br/><i><sub>* count must be a number between 2 and 10</sub></i>", "<br/><b> &middot; </b> " + LulzBot.Trigger);

        if (args.Length == 1)
            LulzBot.Say(chan, helpmsg);
        else
        {
            int max = 5;
			String user = args[1];
			String url = String.Format("http://backend.deviantart.com/rss.xml?q=gallery%3A{0}&type=deviation", user);
            
            if (args.Length == 3)
            {
				if (!int.TryParse(args[2], out max) || max < 2 || max > 10)
				{
					LulzBot.Say(chan, helpmsg);
					return;
				}
			}
			
			String page = Tools.GrabPage(url);
			
			if (page == null)
			{
				LulzBot.Say(chan, "<b>&raquo; Unable to retreive the gallery of "+user+" at the moment.</b>");
				return;
			}
			
			Match res = gallery_re.Match(page);
			
			List<String> thumbs = new List<String>();
			
			while (res.Success)
			{
				thumbs.Add(res.Groups[1].Value);
				res = res.NextMatch();
			}
			
			if (thumbs.Count > max)
			{
				List<String> nthumbs = new List<String>();
				
				String item = "";
				while (nthumbs.Count < max)
				{
					item = thumbs[rand.Next(0, thumbs.Count)];
					
					if (!nthumbs.Contains(item))
						nthumbs.Add(item);
				}
				
				LulzBot.Say(chan, String.Format("<b>&raquo; {0} thumbs from the gallery of :dev{1}:</b><br/><br/> &middot; :thumb{2}:", max, user, String.Join(": :thumb", nthumbs)));
			}
			else
			{
				if (thumbs.Count == 0)
				{
					LulzBot.Say(chan, "<b>&raquo; " + user + " has no deviations!</b>");
					return;
				}
				else
				{
					LulzBot.Say(chan, String.Format("<b>&raquo; {0} thumb{1} from the gallery of :dev{2}:</b><br/><br/> &middot; :thumb{3}:", thumbs.Count, thumbs.Count == 1 ? "" : "s", user, String.Join(": :thumb", thumbs)));
				}
			}
        }
    }
	
	[BindCommand("myart", "Grabs a random set of thumbs from the deviant's gallery.", Privs.Members)]
    public void cmd_myart(String chan, String msg, String[] args, String from)
    {
        String helpmsg = String.Format("<b>&raquo; Usage:</b> {0}myart{0}myart <i>#count</i><br/><br/><i><sub>* count must be a number between 2 and 10</sub></i>", "<br/><b> &middot; </b> " + LulzBot.Trigger);

		int max = 5;
		String user = from;
		String url = String.Format("http://backend.deviantart.com/rss.xml?q=gallery%3A{0}&type=deviation", user);
		
		if (args.Length == 2)
		{
			if (!int.TryParse(args[1], out max) || max < 2 || max > 10)
			{
				LulzBot.Say(chan, helpmsg);
				return;
			}
		}
		
		String page = Tools.GrabPage(url);
		
		if (page == null)
		{
			LulzBot.Say(chan, "<b>&raquo; Unable to retreive the gallery of "+user+" at the moment.</b>");
			return;
		}
		
		Match res = gallery_re.Match(page);
		
		List<String> thumbs = new List<String>();
		
		while (res.Success)
		{
			thumbs.Add(res.Groups[1].Value);
			res = res.NextMatch();
		}
		
		if (thumbs.Count > max)
		{
			List<String> nthumbs = new List<String>();
			
			String item = "";
			while (nthumbs.Count < max)
			{
				item = thumbs[rand.Next(0, thumbs.Count)];
				
				if (!nthumbs.Contains(item))
					nthumbs.Add(item);
			}
			
			LulzBot.Say(chan, String.Format("<b>&raquo; {0} thumbs from the gallery of :dev{1}:</b><br/><br/> &middot; :thumb{2}:", max, user, String.Join(": :thumb", nthumbs)));
		}
		else
		{
			if (thumbs.Count == 0)
			{
				LulzBot.Say(chan, "<b>&raquo; " + user + " has no deviations!</b>");
				return;
			}
			else
			{
				LulzBot.Say(chan, String.Format("<b>&raquo; {0} thumb{1} from the gallery of :dev{2}:</b><br/><br/> &middot; :thumb{3}:", thumbs.Count, thumbs.Count == 1 ? "" : "s", user, String.Join(": :thumb", thumbs)));
			}
		}
    }
}
