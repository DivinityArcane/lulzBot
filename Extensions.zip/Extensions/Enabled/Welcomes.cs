using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using lulzbot;
using lulzbot.Extensions;

[ExtensionInfo("Welcomes", "DivinityArcane", "1.0")]
public class Extension
{
    Dictionary<String, WelcomeChannel> data;

    private void Notify(String ns, String who, String pc, String msg)
    {
        msg = msg.Replace("{from}", who);
        msg = msg.Replace("{chan}", ns);
        msg = msg.Replace("{pc}", pc);
        LulzBot.Say(ns, msg);
    }

    private void InitRoom(String ns)
    {
        if (!data.ContainsKey(ns))
        {
            data.Add(ns, new WelcomeChannel()
            {
                UserWelcomes      = new Dictionary<String, Welcome>(),
                PrivclassWelcomes = new Dictionary<String, Welcome>(),
                RoomWelcome       = String.Empty,
                Enabled           = false
            });
        }
    }

    private void Load()
    {
        data = Storage.Load<Dictionary<String, WelcomeChannel>>("welcomes");

        if (data == null)
            data = new Dictionary<String, WelcomeChannel>();
    }

    private void Save()
    {
        Storage.Save("welcomes", data);
    }

    [BindEvent("recv_join")]
    public void e_welcome(dAmnPacket packet)
    {
        if (data == null)
            Load();

        String ns  = Tools.FormatChat(packet.Parameter);

        if (data.ContainsKey(ns.ToLower()) && data[ns.ToLower()].Enabled)
        {
            WelcomeChannel wc = data[ns.ToLower()];
            String who = packet.SubParameter.ToLower();
            String pc  = packet.Arguments["pc"].ToLower();

            if (wc.UserWelcomes.ContainsKey(who))
            {
                Notify(ns, packet.SubParameter, packet.Arguments["pc"], wc.UserWelcomes[who].Message);
            }
            else if (wc.PrivclassWelcomes.ContainsKey(pc))
            {
                Notify(ns, packet.SubParameter, packet.Arguments["pc"], wc.PrivclassWelcomes[pc].Message);
            }
            else if (wc.RoomWelcome.Length > 0)
            {
                Notify(ns, packet.SubParameter, packet.Arguments["pc"], wc.RoomWelcome);
            }
        }
    }
    
    [BindCommand("welcome", "Manage user welcomes.", Privs.Members)]
    public void cmd_welcome(String chan, String msg, String[] args, String from)
    {
        if (data == null)
            Load();

        String helpmsg = String.Format("<b>&raquo; Usage:</b><br/>{0}welcome <i>[#channel]</i> message<br/>{0}welcome <i>[#channel]</i> clear", " &middot; " + LulzBot.Trigger);
            
        if (args.Length < 2)
        {
            LulzBot.Say(chan, helpmsg);
        }
        else
        {
            String ns, message;

            if (args.Length >= 3 && args[1].StartsWith("#"))
            {
                ns = args[1].ToLower();
                message = msg.Substring(9+ns.Length);
            }
            else
            {
                ns = chan.ToLower();
                message = msg.Substring(8);
            }
            
            String who = from.ToLower();

            if (ns.StartsWith("#"))
            {
                if (ns == "#botdom" || ns == "#datashare")
                {
                    LulzBot.Say(chan, String.Format("<b>&raquo; You cannot set welcomes for {0}</b>", ns));
                    return;
                }
                
                if (!data.ContainsKey(ns)) InitRoom(ns);

                if (!data[ns].UserWelcomes.ContainsKey(who))
                {
                    if (message == "clear")
                    {
                        LulzBot.Say(chan, String.Format("<b>&raquo; You don't have a welcome set for {0}</b>", ns));
                        return;
                    }
                    
                    data[ns].UserWelcomes.Add(who, new Welcome()
                    {
                        Message = message,
                        Author  = from
                    });
                }
                
                if (message == "clear")
                {
                    data[ns].UserWelcomes.Remove(who);
                    LulzBot.Say(chan, String.Format("<b>&raquo; Your welcome for {0} has been cleared.</b>", ns));
                    Save();
                    return;
                }

                Welcome uw = data[ns].UserWelcomes[who];
                uw.Message = message;
                data[ns].UserWelcomes[who] = uw;
                    
                LulzBot.Say(chan, String.Format("<b>&raquo; Your welcome for {0} will be:</b><br/>{1}", ns, message));

                Save();
            }
            else
            {
                LulzBot.Say(chan, helpmsg);
            }
        }
    }

    [BindCommand("welcomes", "Manage channel welcomes.", Privs.Operators)]
    public void cmd_welcomes(String chan, String msg, String[] args, String from)
    {
        if (data == null)
            Load();

        String helpmsg = String.Format("<b>&raquo; Usage:</b><br/>{0}welcomes #channel on/off<br/>{0}welcomes #channel <b>room</b> message/clear<br/>{0}welcomes #channel <b>pc</b> privclass message/clear", " &middot; " + LulzBot.Trigger);
            
        if (args.Length < 3)
        {
            LulzBot.Say(chan, helpmsg);
        }
        else
        {
            String ns = args[1].ToLower();
            String arg = args[2].ToLower();

            if (ns.StartsWith("#"))
            {
                if (ns == "#botdom" || ns == "#datashare")
                {
                    LulzBot.Say(chan, String.Format("<b>&raquo; You cannot set welcomes for {0}</b>", args[1]));
                    return;
                }
                
                if (arg == "on" || arg == "off")
                {
                    if (!data.ContainsKey(ns)) InitRoom(ns);

                    WelcomeChannel wc = data[ns];
                    wc.Enabled        = (arg == "on");
                    data[ns]          = wc;
                    Save();

                    LulzBot.Say(chan, String.Format("<b>&raquo; Welcomes for {0} have been {1}.</b>", args[1], (arg == "on" ? "enabled" : "disabled")));
                }
                else if (args.Length >= 4 &&arg == "room")
                {
                    if (!data.ContainsKey(ns)) InitRoom(ns);

                    String message     = msg.Substring(15 + ns.Length);
                    
                    WelcomeChannel wc  = data[ns];

                    if (message == "clear")
                    {
                        wc.RoomWelcome = String.Empty;
                        data[ns]       = wc;
                        Save();
                        LulzBot.Say(chan, String.Format("<b>&raquo; Welcome for {0} has been cleared.</b>", args[1]));
                        return;
                    }
                    
                    wc.RoomWelcome     = message;
                    data[ns]           = wc;
                    Save();

                    LulzBot.Say(chan, String.Format("<b>&raquo; Welcome for {0} has been set to:</b><br/>{1}", args[1], message));
                }
                else if (args.Length >= 5 && arg == "pc")
                {
                    String pc      = args[3];
                    String rns     = Tools.FormatChat(ns);
                    String message = msg.Substring(14 + ns.Length + pc.Length);
                    
                    WelcomeChannel wc  = data[ns];

                    if (message == "clear")
                    {
                        if (!wc.PrivclassWelcomes.ContainsKey(pc.ToLower()))
                        {
                            LulzBot.Say(chan, String.Format("<b>&raquo; No welcome is set for privclass {0} in {1}.</b>", pc, args[1]));
                            return;
                        }
                        
                        wc.PrivclassWelcomes.Remove(pc.ToLower());
                        data[ns]       = wc;
                        Save();
                        LulzBot.Say(chan, String.Format("<b>&raquo; Welcome for privclass {0} in {1} has been cleared.</b>", pc, args[1]));
                        return;
                    }

                    if (!Core.ChannelData.ContainsKey(rns))
                    {
                        LulzBot.Say(chan, "<b>&raquo; The bot is not in that channel.</b>");
                        return;
                    }
                    else if (!Core.ChannelData[rns].Privclasses.ContainsKey(pc.ToLower()))
                    {
                        LulzBot.Say(chan, "<b>&raquo; No such privclass exists in that channel.</b>");
                        return;
                    }

                    if (!wc.PrivclassWelcomes.ContainsKey(pc.ToLower()))
                        wc.PrivclassWelcomes.Add(pc.ToLower(), new Welcome()
                        {
                            Message = String.Empty,
                            Author  = String.Empty
                        });
                    
                    Welcome pcw     = wc.PrivclassWelcomes[pc.ToLower()];
                    pcw.Message     = message;
                    pcw.Author      = from;
                    wc.PrivclassWelcomes[pc.ToLower()] = pcw;
                    data[ns]        = wc;
                    Save();

                    LulzBot.Say(chan, String.Format("<b>&raquo; Welcome for privclass {0} in {1} has been set to:</b><br/>{2}", pc, args[1], message));
                }
                else
                {
                    LulzBot.Say(chan, helpmsg);
                }
            }
            else
            {
                LulzBot.Say(chan, helpmsg);
            }
        }
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 0)]
public struct Welcome
{
    public String Message;
    public String Author;
}

[StructLayout(LayoutKind.Sequential, Pack = 0)]
public struct WelcomeChannel
{
    public Dictionary<String, Welcome> UserWelcomes;
    public Dictionary<String, Welcome> PrivclassWelcomes;
    public String RoomWelcome;
    public Boolean Enabled;
} 
