using System;
using Newtonsoft.Json.Linq;
using lulzbot;
using lulzbot.Extensions;

[ExtensionInfo("dAmnIdlers", "DivinityArcane", "1.0")]
public class Extension
{
    [BindCommand("irpg", "#dAmnIdlers info command!", Privs.Guest)]
    public void cmd_irpg(String chan, String msg, String[] args, String from)
    {
        if (args.Length == 1)
            LulzBot.Say(chan, String.Format("<b>Usage:</b> {0}irpg <i>username</i>", LulzBot.Trigger));
        else
        {
            var query = @"http://damnidlers.shadowkitsune.net/database.php?fmt=json&user=" + args[1];
            var json = Tools.GrabPage(query);
            
            if (json == null || json == "Server busy")
            {
                ConIO.Write(json);
                LulzBot.Say(chan, "<b>Error:</b> The server is busy, try again later.");
                return;
            }
            
            var data = JObject.Parse(json);
            
            if (data[".status"].ToString() != "ok")
            {
                LulzBot.Say(chan, "<b>Error:</b> Request failed. Is that user really a player in #dAmnIdlers ?");
                return;
            }
            
            var output = "<b> :bulletorange: Player information for <a href=\"http://damnidlers.shadowkitsune.net/?q=" + args[1] + "\">" + args[1] + "</a>:</b><br/><br/>";
            output += "<b> Level:</b> " + data["Level"].ToString() + "<br/>";
            output += "<b> Class:</b> " + data["Class"].ToString() + "<br/>";
            output += "<b> Alignment:</b> " + data["Alignment"].ToString() + "<br/>";
            output += "<b> Time registered:</b> " + Tools.FormatTime((int)Bot.EpochTimestamp - (int)data.Value<int>("Joined")) + "<br/>";
            output += "<b> Time idled:</b> " + Tools.FormatTime((int)data.Value<int>("Idled")) + "<br/>";
            output += "<b> Time penalized:</b> " + Tools.FormatTime((int)data.Value<int>("Penalized")) + "<br/>";
            output += "<b> Time to next level:</b> " + Tools.FormatTime((int)data.Value<int>("ToLevel")) + "<br/>";
            output += "<b> Information last updated:</b> " + data[".last_updated"].ToString() + "<br/>";
            output += "<br/><i> For rankings, <a href=\"http://damnidlers.shadowkitsune.net/\">click here.</a></i>";
            
            LulzBot.Say(chan, output);
        }
    }
}
